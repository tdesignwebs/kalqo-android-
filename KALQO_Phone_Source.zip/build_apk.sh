#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v flutter >/dev/null || { echo 'Flutter SDK is missing. Install Flutter and Android Studio first.'; exit 2; }
command -v python3 >/dev/null || { echo 'Python 3 is needed to patch Android assets.'; exit 2; }
flutter create --platforms=android --org com.axreon --project-name kalqo .
python3 tool/prepare_android.py
flutter pub get
flutter test
flutter build apk --debug
printf '\nYour APK: %s\n' "$(pwd)/build/app/outputs/flutter-apk/app-debug.apk"
