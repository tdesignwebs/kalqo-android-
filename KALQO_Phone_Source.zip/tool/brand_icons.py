from PIL import Image
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'assets/icon'
icon=Image.open(root/'assets/icon/icon_artwork.png').convert('RGBA')
icon=icon.resize((1024,1024),Image.Resampling.LANCZOS)
icon.save(out/'kalqo_icon.png')
icon.save(out/'adaptive_foreground.png')
for name, size in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
    icon.resize((size,size),Image.Resampling.LANCZOS).save(out/f'ic_launcher_{name}.png')
splash=Image.new('RGBA',(360,360),(0,0,0,0))
splash.alpha_composite(icon.resize((192,192),Image.Resampling.LANCZOS),(84,84))
splash.save(out/'splash.png')
(out/'ic_launcher_48.png').write_bytes((out/'ic_launcher_mdpi.png').read_bytes())
(out/'ic_launcher_72.png').write_bytes((out/'ic_launcher_hdpi.png').read_bytes())
(out/'ic_launcher_96.png').write_bytes((out/'ic_launcher_xhdpi.png').read_bytes())
(out/'ic_launcher_144.png').write_bytes((out/'ic_launcher_xxhdpi.png').read_bytes())
(out/'ic_launcher_192.png').write_bytes((out/'ic_launcher_xxxhdpi.png').read_bytes())
(root/'android_patches/app/src/main/res/drawable/kalqo_splash.png').write_bytes(splash.read_bytes() if hasattr(splash,'read_bytes') else (out/'splash.png').read_bytes())
print('KALQO Orbit icon assets generated.')
