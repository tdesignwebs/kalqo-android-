#!/usr/bin/env python3
"""Apply native Android app wiring after 'flutter create --platforms=android'."""
from pathlib import Path
from shutil import copytree
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
android = root / 'android'
if not android.exists():
    raise SystemExit('Run flutter create --platforms=android --org com.axreon . first')
patches = root / 'android_patches'
if not patches.exists():
    raise SystemExit('Android patches folder missing')
copytree(patches, android, dirs_exist_ok=True)
manifest = android / 'app/src/main/AndroidManifest.xml'
ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
tree = ET.parse(manifest)
root_element = tree.getroot()
app = root_element.find('application')
if app is None:
    raise SystemExit('Unexpected AndroidManifest: no application element')
ns = '{http://schemas.android.com/apk/res/android}'
# Vehicle lookups require internet; all finance calculations remain offline.
if not any(x.tag == 'uses-permission' and x.get(ns+'name') == 'android.permission.INTERNET' for x in root_element):
    root_element.insert(0, ET.Element('uses-permission', {ns+'name': 'android.permission.INTERNET'}))
app.set(ns+'label', 'KALQO')
for x in list(app):
    if x.tag == 'provider' and x.get(ns+'authorities') == '${applicationId}.provider':
        app.remove(x)
provider = ET.SubElement(app, 'provider', {
    ns+'name': 'androidx.core.content.FileProvider',
    ns+'authorities': '${applicationId}.provider',
    ns+'exported': 'false',
    ns+'grantUriPermissions': 'true',
})
ET.SubElement(provider, 'meta-data', {
    ns+'name': 'android.support.FILE_PROVIDER_PATHS',
    ns+'resource': '@xml/file_paths',
})
tree.write(manifest, encoding='utf-8', xml_declaration=True)
# Android launcher icons from the generated branding resources.
for size, bucket in [(48, 'mdpi'), (72, 'hdpi'), (96, 'xhdpi'), (144, 'xxhdpi'), (192, 'xxxhdpi')]:
    icon = root / 'assets/icon' / f'ic_launcher_{size}.png'
    if icon.exists():
        folder = android / 'app/src/main/res' / f'mipmap-{bucket}'
        folder.mkdir(parents=True, exist_ok=True)
        (folder/'ic_launcher.png').write_bytes(icon.read_bytes())
# FileProvider is supplied by AndroidX Core. Inject explicit dependency so
# generated Flutter Gradle templates don't rely on transitive packages.
for gradle_name in ['build.gradle.kts', 'build.gradle']:
    gradle = android / 'app' / gradle_name
    if gradle.exists():
        body = gradle.read_text()
        if 'androidx.core:core:' not in body:
            line = 'dependencies {\n    implementation(\"androidx.core:core:1.15.0\")\n}\n' if gradle_name.endswith('.kts') else "dependencies {\n    implementation 'androidx.core:core:1.15.0'\n}\n"
            gradle.write_text(body.rstrip() + '\n\n' + line)
        break
print('Native Android KALQO patch applied.')
