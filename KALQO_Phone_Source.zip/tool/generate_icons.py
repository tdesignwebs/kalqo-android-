from PIL import Image, ImageDraw
from pathlib import Path

out = Path(__file__).resolve().parents[1]/'assets/icon'
out.mkdir(parents=True, exist_ok=True)
blue = (58, 145, 255, 255)
white = (247, 249, 253, 255)
black = (18, 21, 27, 255)

def render(size, transparent=False):
    image=Image.new('RGBA', (1024,1024), (0,0,0,0) if transparent else black)
    draw=ImageDraw.Draw(image)
    if not transparent:
        draw.rounded_rectangle((0,0,1023,1023),radius=230,fill=black)
    # K — 3 deliberate strokes cut like engineered metallic geometry.
    draw.rounded_rectangle((260,233,337,793),radius=23,fill=white)
    draw.polygon([(369,500),(625,237),(730,237),(452,522)],fill=white)
    draw.polygon([(455,498),(735,788),(627,788),(370,522)],fill=white)
    # Sharp blue financial tick, visual cue to interest/growth.
    draw.rounded_rectangle((699,226,775,302),radius=24,fill=blue)
    if transparent:
        # Safe inset around all foreground objects
        pass
    return image.resize((size,size), Image.Resampling.LANCZOS)

render(1024).save(out/'kalqo_icon.png')
render(1024,True).save(out/'adaptive_foreground.png')
# Native splash asset padded, to avoid overflowing across screen densities.
splash=Image.new('RGBA',(360,360),(0,0,0,0))
splash.alpha_composite(render(192),(84,84))
splash.save(out/'splash.png')
for scale, size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    render(size).save(out/f'ic_launcher_{scale}.png')
# Explicit SVG source that can be edited without rasterization artifacts.
(out/'kalqo_icon.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
<rect width="1024" height="1024" rx="230" fill="#12151B"/>
<rect x="260" y="233" width="77" height="560" rx="23" fill="#F7F9FD"/>
<path d="M369 500L625 237H730L452 522Z" fill="#F7F9FD"/>
<path d="M455 498L735 788H627L370 522Z" fill="#F7F9FD"/>
<rect x="699" y="226" width="76" height="76" rx="24" fill="#3A91FF"/>
</svg>''',encoding='utf8')
print('Generated custom KALQO icon pack')
