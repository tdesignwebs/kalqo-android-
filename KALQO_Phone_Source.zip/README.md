# KALQO — Smart Calculator for Android

**Project:** `com.axreon.kalqo` | **Flutter/Dart** | **Offline** | **No login / ads / analytics**

KALQO contains three functional calculator views: normal expression calculator, Turkish bank interest with tables/compound payouts, and AXREON SaaS financial dashboard with editable plans, costs, VAT, Dutch tax estimates, growth simulator, CSV/PDF reports, and saved scenarios.

## Building a real Android APK

This source archive **does not include a compiled APK**. The assembly environment in which it was prepared did not contain Flutter, the Android SDK, Gradle or Android build artifacts and could not access the SDK download servers. **No APK build or Flutter test execution has been claimed.**

On a Mac, Linux or Windows developer machine with [Flutter](https://docs.flutter.dev/get-started/install), [Android SDK](https://developer.android.com/studio), and Java installed, extract this ZIP and run:

```bash
cd kalqo_flutter
flutter doctor
bash build_apk.sh
```

This scaffolds Android, applies the custom launcher and splash assets, adds the secure file sharing channel, runs unit tests, and builds a debug APK.

**APK output:** `build/app/outputs/flutter-apk/app-debug.apk`

For a production signed release, create your own signing keystore and follow the official Flutter guide: https://docs.flutter.dev/deployment/android . Do not publish a debug-signed APK as a production release.

On Windows PowerShell (without bash), run:

```powershell
flutter create --platforms=android --org com.axreon --project-name kalqo .
python tool/prepare_android.py
flutter pub get
flutter test
flutter build apk --debug
```

To install for testing, transfer the APK to your phone and open it (allow installation for the trusted file manager if prompted). Alternatively connect a device with USB debugging and use `flutter install`.

## Financial conventions

- Arbitrary-size BigInt fixed-point arithmetic with **12 decimal places**; only displayed amounts rounded.
- Interest uses `P × (annualRate/100) × days / basis` each term; withholding is applied to that gross interest; optional reinvestment of net interest. Fixed 31-day periods are **not** mislabeled calendar months.
- Calendar mode uses the actual Gregorian length of each calendar month. In calendar mode the day count of each period is the number of days in its month, beginning with the start month's first day.
- Annual hosting/domain subscriptions are prorated monthly. One-time expenses are tracked but intentionally excluded from the recurring MRR model.
- For expenses, VAT treatment `exempt` means no estimated recoverable VAT; `excluded` amounts are net and `included` amounts are gross. Eligibility for VAT deductions is assumed where indicated and must be verified.
- Prices that include VAT are converted to net revenue before profit calculation. VAT is not income.
- Basic tax reserve defaults to 30% and is deliberately not presented as actual tax due.
- Verified **2026** Dutch box 1 rates (non-AOW): 35.75% until €38,883, 37.56% up to €78,426, 49.50% above. Self-employed deduction 2026 €1,200; eligible starter supplement €2,123; MKB exemption 12.7%; Zvw 4.85% with max €79,409. Models simplify deduction-rate caps and tax credits.
- Verified **2026** BV corporate tax: 19% up to €200,000 and 25.8% above. Dividend and personal salary tax NOT modeled. BV 'remaining' isn't take-home pay.
- EUR/TRY/USD currency dropdown affects units only, **not live exchange-rate conversion**; the app works offline.
- Turkish stopaj defaults to an *editable illustrative rate* of 17.5%; banking and cross-border taxes can differ.

## Official Dutch references (accessed 2026-10-16)

- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/prive/inkomstenbelasting/heffingskortingen_boxen_tarieven/boxen_en_tarieven/box_1/box_1
- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/inkomstenbelasting/veranderingen-inkomstenbelasting-2026/ondernemersaftrek-2026/zelfstandigenaftrek-2026
- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/inkomstenbelasting/veranderingen-inkomstenbelasting-2026/mkb-winstvrijstelling-2026
- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/winst/vennootschapsbelasting/veranderingen-vennootschapsbelasting-2026/
- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/prive/werk_en_inkomen/zorgverzekeringswet/veranderingen-bijdrage-zvw/
- https://www.belastingdienst.nl/wps/wcm/connect/bldcontentnl/belastingdienst/zakelijk/btw/btw_berekenen_aan_uw_klanten/btw_berekenen/btw_tarief/btw_tarief

## Limitations before production release

- Automated Flutter tests are included, but **not executed here** because the SDK is absent; test and fix build/version issues before distributing.
- True Sora/DM Sans font files are not bundled; the project uses the platform sans-serif fallback. Licensed font assets may be added locally later.
- English, Dutch and Turkish are supported as settings and selected on-screen labels; the entire interface is **not fully translated** yet. Full ARB localization is future work.
- PDF generator is intentionally dependency-free and outputs ASCII only. Non-ASCII glyphs in reports are substituted. CSV supports UTF-8.
- This is an offline personal scenario estimator, not accredited accounting or tax software. No live banking rates, currency feeds, legal eligibility verification or professional filing system.
- The charts are built with CustomPainter and need on-device visual inspection.


## Build status and native bridge

The project includes the Android FileProvider/MethodChannel source files and a CI workflow in `.github/workflows/android.yml`. Flutter and the Android SDK are not installed in the project-generation environment, so **no Android APK has been compiled or device-tested**. Use `HOW_TO_GET_ANDROID_APK.txt` to build on GitHub Actions or locally. A green GitHub Actions run publishes the test APK as an artifact.
