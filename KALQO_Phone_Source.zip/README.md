# KALQO 3.0 — Finance × Garage

A native Flutter Android app with **Dark / Light / System** themes, redesigned menu and selection sheets, calculations and an interactive car inspection map.

## Included in the release

- Calculator: decimal-safe calculation history, percentage, arithmetic.
- Faiz: Turkish 31-day deposit return, tax withholding, reinvestment, tables and export.
- AXREON: SaaS subscription projections, expenses, VAT, estimated Dutch tax.
- Cars (new): online Netherlands **RDW** lookup by plate, US **NHTSA** VIN decoding, German plate manual-inspection mode.
- Interactive top-down car body diagram: tap *Edit* and then the panel to record **damage (red)**, **repainted (orange)**, **checked clear (subtle green)** or **unknown**. This is **manual inspection data**, not sourced accident history.
- Manual mileage field. The public RDW API returns only an *odometer judgement* and the *year of last registration*, **not current mileage**.
- Per-vehicle local notes keyed by country and plate/VIN so markings do not leak across vehicles.
- A new segmented-ring icon with electric-blue detail (replacing old K monogram), plus 4-tab navigation, editorial number fields and bottom-sheet selectors.
- Restores and persists financial preferences and notes locally via existing `AppStore`. Online lookups need internet access, but financial calculations still work offline.

## Accuracy limitations

RDW data is a public register, **not** a collision history report and does not provide a vehicle's exact current odometer reading. NHTSA's free VIN decoder is **not a US plate lookup** or accident-history source. Germany does not offer an unrestricted public plate-to-vehicle/history API. No collision, damage, ownership, odometer or paint findings are fabricated. A licensed history provider must be connected in a future release for verifiable repair/accident records.

References:
- RDW official open data: https://www.rdw.nl/over-rdw/dienstverlening/open-data/algemene-informatie
- RDW vehicle API: https://opendata.rdw.nl/resource/m9d7-ebf2.json?kenteken=23LJLJ
- RDW fuel API: https://opendata.rdw.nl/resource/8ys7-d773.json?kenteken=23LJLJ
- NHTSA vPIC: https://vpic.nhtsa.dot.gov/api/

## Install v3 from your Samsung using your existing GitHub Actions

1. Open GitHub repository **tdesignwebs/kalqo-android-** on mobile.
2. If `KALQO_Phone_Source.zip` is already present, replace it with the v3 ZIP (renamed exactly `KALQO_Phone_Source.zip`): delete old file and commit if GitHub's uploader does not allow replacement; then upload v3 ZIP and commit.
3. Existing `.github/workflows/build-apk.yml` automatically unzips `KALQO_Phone_Source.zip` into the checkout, runs `flutter create`, executes `tool/prepare_android.py` to enable Internet permission/branding/native share bridge, then analyzes/tests/builds a debug APK.
4. Open Actions > successful run > Artifacts > **KALQO-Samsung-APK** and extract `app-debug.apk`.
5. Save any important old data before installing. Reusing the same package ID and signature may permit in-place update; otherwise you might need to uninstall the old debug build first. Uninstalling can erase locally stored data.

IMPORTANT: This source is a build candidate, not a compiled APK; its Dart/Flutter tests must run in GitHub before claiming installability.

## Engineering

- Flutter, Dart, Material 3. No third-party runtime dependencies.
- Data: `lib/core/storage.dart`, `lib/core/finance.dart`, `lib/core/vehicle.dart`.
- UI: `lib/ui/common.dart`, `calculator.dart`, `faiz.dart`, `business.dart`, `cars.dart`.
- Tests: `test/finance_test.dart`, `test/vehicle_test.dart`.
- Native wiring: `tool/prepare_android.py` runs after platform generation; requires the Android SDK on build machine. Finance screens offline, Cars online.

Run in a configured Flutter environment:

```shell
flutter create --platforms=android --org com.axreon --project-name kalqo .
python3 tool/prepare_android.py
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```
