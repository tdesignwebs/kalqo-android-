package com.axreon.kalqo

import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.axreon.kalqo/files")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "dataDirectory" -> result.success(filesDir.absolutePath)
                    "shareFile" -> {
                        try {
                            val path = call.argument<String>("path")
                                ?: throw IllegalArgumentException("Missing file path")
                            val mime = call.argument<String>("mime") ?: "application/octet-stream"
                            val file = File(path).canonicalFile
                            val allowed = File(filesDir, "reports").canonicalFile
                            if (!file.path.startsWith(allowed.path + File.separator) || !file.isFile) {
                                throw SecurityException("File must be inside app reports directory")
                            }
                            val uri: Uri = FileProvider.getUriForFile(this,
                                "${applicationContext.packageName}.provider", file)
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = mime
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(share, "Share KALQO report"))
                            result.success(true)
                        } catch (e: Exception) {
                            result.error("SHARE_FAILED", e.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
