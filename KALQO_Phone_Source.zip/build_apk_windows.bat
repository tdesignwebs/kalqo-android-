@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter SDK is not installed or not on PATH.
  echo See https://docs.flutter.dev/get-started/install
  pause
  exit /b 1
)
where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python is not installed or not on PATH.
  pause
  exit /b 1
)
call flutter create --platforms=android --org com.axreon --project-name kalqo .
if errorlevel 1 goto failed
python tool\prepare_android.py
if errorlevel 1 goto failed
call flutter pub get
if errorlevel 1 goto failed
call flutter test
if errorlevel 1 goto failed
call flutter build apk --debug
if errorlevel 1 goto failed
if not exist build\app\outputs\flutter-apk\app-debug.apk goto failed
echo.
echo SUCCESS: build\app\outputs\flutter-apk\app-debug.apk
pause
exit /b 0
:failed
echo ERROR: Build or tests failed. See console output.
pause
exit /b 1
