import 'decimal.dart';

class InterestRow {
  final int period;
  final int days;
  final Dec starting, gross, tax, net, ending, accumulated;
  InterestRow(this.period, this.days, this.starting, this.gross, this.tax, this.net, this.ending, this.accumulated);
}

class InterestResult {
  final List<InterestRow> rows;
  final Dec totalGross, totalTax, totalNet, closingBalance;
  InterestResult(this.rows, this.totalGross, this.totalTax, this.totalNet, this.closingBalance);
}

class InterestInput {
  final Dec principal, annualPercent, taxPercent;
  final int days, periods, basis;
  final bool reinvest, calendarMode;
  final DateTime startDate;
  InterestInput({required this.principal, required this.annualPercent, required this.taxPercent,
    this.days = 31, this.periods = 12, this.basis = 365, this.reinvest = true,
    this.calendarMode = false, DateTime? startDate}) : startDate = startDate ?? DateTime(2026, 1, 1);
}

InterestResult calculateInterest(InterestInput i) {
  if (i.principal < Dec.zero || i.days < 1 || i.periods < 1 || i.periods > 600 || i.basis < 1 ||
      i.annualPercent < Dec.zero || i.taxPercent < Dec.zero || i.taxPercent > Dec.fromInt(100)) {
    throw ArgumentError('Check interest inputs');
  }
  final rows = <InterestRow>[];
  var balance = i.principal;
  var totalGross = Dec.zero, totalTax = Dec.zero, totalNet = Dec.zero;
  for (var p = 1; p <= i.periods; p++) {
    int days = i.days;
    if (i.calendarMode) {
      final first = DateTime.utc(i.startDate.year, i.startDate.month + p - 1, 1);
      final after = DateTime.utc(first.year, first.month + 1, 1);
      days = after.difference(first).inDays;
    }
    final start = balance;
    final gross = start * i.annualPercent.pct() * Dec.fromInt(days) / Dec.fromInt(i.basis);
    final tax = gross * i.taxPercent.pct();
    final net = gross - tax;
    totalGross += gross;
    totalTax += tax;
    totalNet += net;
    if (i.reinvest) balance += net;
    rows.add(InterestRow(p, days, start, gross, tax, net, balance, totalNet));
  }
  return InterestResult(rows, totalGross, totalTax, totalNet, balance);
}

/// Values are assumed monthly except when labeled otherwise.
enum ExpenseFrequency { monthly, yearly, once }
enum ExpenseVat { excluded, included, exempt }
class BusinessExpense {
  final String id, name;
  final Dec amount;
  final ExpenseFrequency frequency;
  final ExpenseVat vatTreatment;
  final bool enabled;
  BusinessExpense({required this.id, required this.name, required this.amount,
    this.frequency = ExpenseFrequency.monthly, this.vatTreatment = ExpenseVat.exempt, this.enabled = true});
  Dec monthlyAmount() {
    if (!enabled) return Dec.zero;
    if (frequency == ExpenseFrequency.yearly) return amount / Dec.fromInt(12);
    if (frequency == ExpenseFrequency.once) return Dec.zero; // One-off outside recurring MRR model
    return amount;
  }
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'amount': amount.toFixed(6),
    'frequency': frequency.name, 'vat': vatTreatment.name, 'enabled': enabled};
  factory BusinessExpense.fromJson(Map<String, dynamic> m) => BusinessExpense(
    id: '${m['id']}', name: '${m['name']}', amount: Dec.parse('${m['amount']}'),
    frequency: ExpenseFrequency.values.firstWhere((e) => e.name == m['frequency'], orElse: () => ExpenseFrequency.monthly),
    vatTreatment: ExpenseVat.values.firstWhere((e) => e.name == m['vat'], orElse: () => ExpenseVat.exempt),
    enabled: m['enabled'] != false);
}

class BusinessInput {
  final List<int> clients;
  final List<Dec> prices;
  final bool pricesIncludeVat;
  final Dec vatRate, providerPercent, providerFixed;
  final int monthlyTransactions;
  final List<BusinessExpense> expenses;
  BusinessInput({required this.clients, required this.prices, required this.expenses,
    this.pricesIncludeVat = false, required this.vatRate,
    required this.providerPercent, required this.providerFixed, this.monthlyTransactions = 0});
}

class BusinessResult {
  final int totalClients;
  final Dec monthlyRevenue, invoiced, outputVat, inputVat, netVat,
    monthlyExpenses, processingFees, operatingProfit, annualProfit;
  BusinessResult(this.totalClients, this.monthlyRevenue, this.invoiced, this.outputVat,
    this.inputVat, this.netVat, this.monthlyExpenses, this.processingFees,
    this.operatingProfit, this.annualProfit);
}

BusinessResult calculateBusiness(BusinessInput i) {
  if (i.clients.length != i.prices.length || i.clients.isEmpty || i.clients.any((n) => n < 0) ||
      i.prices.any((p) => p < Dec.zero) || i.vatRate < Dec.zero || i.vatRate > Dec.fromInt(100)) {
    throw ArgumentError('Invalid business inputs');
  }
  final total = i.clients.fold<int>(0, (a, b) => a + b);
  var amount = Dec.zero;
  for (var j = 0; j < i.clients.length; j++) {
    amount += Dec.fromInt(i.clients[j]) * i.prices[j];
  }
  final vatMultiplier = Dec.one + i.vatRate.pct();
  final revenue = i.pricesIncludeVat ? amount / vatMultiplier : amount;
  final outputVat = revenue * i.vatRate.pct();
  final invoiced = revenue + outputVat;
  var costs = Dec.zero, inputVat = Dec.zero;
  for (final e in i.expenses) {
    final a = e.monthlyAmount();
    if (e.vatTreatment == ExpenseVat.included) {
      final net = a / vatMultiplier;
      costs += net;
      inputVat += a - net;
    } else if (e.vatTreatment == ExpenseVat.excluded) {
      costs += a;
      inputVat += a * i.vatRate.pct();
    } else {
      costs += a;
    }
  }
  final providerFees = revenue * i.providerPercent.pct() + i.providerFixed * Dec.fromInt(i.monthlyTransactions);
  costs += providerFees; // Assumed without recoverable VAT unless specified separately.
  final operating = revenue - costs;
  return BusinessResult(total, revenue, invoiced, outputVat, inputVat,
    outputVat - inputVat, costs, providerFees, operating, operating * Dec.fromInt(12));
}

enum TaxMode { simple, soleTrader, bv }
class TaxInput {
  final TaxMode mode;
  final int year;
  final Dec effectivePercent, otherIncome, manualCredits, otherDeduction, salaryCost, expectedDividends;
  final bool qualifyingEntrepreneur, meetsHours, starter, applyMkb, includeZvw;
  TaxInput({this.mode = TaxMode.simple, this.year = 2026,
    required this.effectivePercent, required this.otherIncome, required this.manualCredits,
    required this.otherDeduction, required this.salaryCost, required this.expectedDividends,
    this.qualifyingEntrepreneur = false, this.meetsHours = false, this.starter = false,
    this.applyMkb = false, this.includeZvw = false});
}
class TaxResult {
  final Dec yearlyIncomeTax, yearlyZvw, yearlyBusinessTax, yearlyAfterTax, taxableBase;
  final String explanation;
  final bool estimated;
  TaxResult(this.yearlyIncomeTax, this.yearlyZvw, this.yearlyBusinessTax,
    this.yearlyAfterTax, this.taxableBase, this.explanation, {this.estimated = true});
}

Dec progressiveBox1(Dec income) {
  final a = income.positive;
  final cut1 = Dec.fromInt(38883), cut2 = Dec.fromInt(78426);
  final first = a.min(cut1);
  final middle = (a - cut1).positive.min(cut2 - cut1);
  final upper = (a - cut2).positive;
  return pct(first, Dec.parse('35.75')) + pct(middle, Dec.parse('37.56')) + pct(upper, Dec.parse('49.50'));
}
Dec corporateTax(Dec yearlyProfit) {
  final a = yearlyProfit.positive;
  final limit = Dec.fromInt(200000);
  return pct(a.min(limit), Dec.fromInt(19)) + pct((a - limit).positive, Dec.parse('25.8'));
}
TaxResult estimateTax(Dec annualProfit, TaxInput i) {
  final profit = annualProfit.positive;
  if (i.mode == TaxMode.simple) {
    final tax = pct(profit, i.effectivePercent);
    return TaxResult(tax, Dec.zero, tax, annualProfit - tax, profit,
      'Simple effective tax reserve; not a legal tax assessment.');
  }
  if (i.year != 2026) {
    return TaxResult(Dec.zero, Dec.zero, Dec.zero, annualProfit, profit,
      'No verified rates for this tax year. Tax not estimated. Switch to 2026 or Simple mode.', estimated: false);
  }
  if (i.mode == TaxMode.bv) {
    final afterSalary = (profit - i.salaryCost).positive;
    final tax = corporateTax(afterSalary);
    return TaxResult(tax, Dec.zero, tax, annualProfit - i.salaryCost - tax,
      afterSalary, 'BV company-level corporate tax only. Salary, box 2/dividends, and owner take-home taxes are not estimated.');
  }
  Dec base = profit;
  if (i.qualifyingEntrepreneur && i.meetsHours) {
    final deduction = Dec.fromInt(1200) + (i.starter ? Dec.fromInt(2123) : Dec.zero);
    base = (base - deduction).positive;
  }
  if (i.qualifyingEntrepreneur && i.applyMkb) {
    base -= pct(base, Dec.parse('12.7'));
  }
  base = (base - i.otherDeduction).positive;
  final totalTaxable = base + i.otherIncome.positive;
  // Marginal tax attributable to business, before manually entered credits.
  final deltaTax = (progressiveBox1(totalTaxable) - progressiveBox1(i.otherIncome.positive)).positive;
  final incomeTax = (deltaTax - i.manualCredits).positive;
  Dec zvw = Dec.zero;
  if (i.includeZvw) {
    // Simplified maximum assumes no other income consumed contribution ceiling.
    zvw = pct(base.min(Dec.fromInt(79409)), Dec.parse('4.85'));
  }
  return TaxResult(incomeTax, zvw, incomeTax + zvw, annualProfit - incomeTax - zvw,
    base, 'Partial estimate only: manual credits, hours test, deduction caps, Zvw allocation, and capped deduction benefits require validation.');
}

class GrowthRow {
  final int month, clients;
  final Dec revenue, expenses, operating, estimatedTax, net, cumulative;
  GrowthRow(this.month, this.clients, this.revenue, this.expenses,
      this.operating, this.estimatedTax, this.net, this.cumulative);
}
List<GrowthRow> simulateGrowth({required int startClients, required int newClients,
  required Dec churnPercent, required Dec price, required Dec startingExpenses,
  required Dec expenseGrowthPercent, required Dec effectiveTaxPercent, int months = 12}) {
  if (startClients < 0 || newClients < 0 || months < 1 || months > 120 ||
      churnPercent < Dec.zero || churnPercent > Dec.fromInt(100)) throw ArgumentError('Invalid growth inputs');
  var clients = Dec.fromInt(startClients);
  var expenses = startingExpenses;
  var cumulative = Dec.zero;
  final result = <GrowthRow>[];
  for (var month = 1; month <= months; month++) {
    clients = (clients * (Dec.one - churnPercent.pct()) + Dec.fromInt(newClients)).positive;
    final count = int.parse(clients.toFixed(0));
    final revenue = Dec.fromInt(count) * price;
    final operating = revenue - expenses;
    final taxes = pct(operating.positive, effectiveTaxPercent);
    final net = operating - taxes;
    cumulative += net;
    result.add(GrowthRow(month, count, revenue, expenses, operating, taxes, net, cumulative));
    expenses *= Dec.one + expenseGrowthPercent.pct();
  }
  return result;
}
