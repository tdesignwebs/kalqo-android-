import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

const androidBridge = MethodChannel('com.axreon.kalqo/files');

class AppStore extends ChangeNotifier {
  String theme = 'system';
  String language = 'nl';
  int decimals = 2;
  final List<Map<String, String>> history = [];
  final List<Map<String, dynamic>> scenarios = [];
  final Map<String, dynamic> drafts = {};
  final Map<String, String> preferences = {
    'bankRate':'32', 'bankTax':'17.5', 'bankDays':'31',
    'basicPrice':'39', 'mediumPrice':'59', 'proPrice':'79', 'vatRate':'21',
  };
  Directory? folder;
  Timer? _pending;
  bool loaded = false;

  Future<void> init() async {
    try {
      final path = await androidBridge.invokeMethod<String>('dataDirectory');
      if (path != null) folder = Directory(path);
    } on PlatformException catch (_) {
      // Desktop preview / tests: local directory, not Android persisted data.
      folder = Directory('${Directory.systemTemp.path}/kalqo_preview');
    } on MissingPluginException catch (_) {
      folder = Directory('${Directory.systemTemp.path}/kalqo_preview');
    }
    try {
      await folder?.create(recursive: true);
      final file = File('${folder!.path}/kalqo_data.json');
      if (await file.exists()) {
        final m = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
        theme = '${m['theme'] ?? 'system'}';
        language = '${m['language'] ?? 'nl'}';
        decimals = (m['decimals'] as num?)?.toInt() ?? 2;
        history.addAll(((m['history'] as List?) ?? []).map((e) => Map<String, String>.from(e as Map)));
        scenarios.addAll(((m['scenarios'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)));
        drafts.addAll(Map<String, dynamic>.from((m['drafts'] as Map?) ?? {}));
        final prefs = m['preferences'];
        if (prefs is Map) for (final entry in prefs.entries) { preferences['${entry.key}'] = '${entry.value}'; }
      }
    } catch (_) {
      // Corrupted local JSON should not prevent the calculator from starting.
    }
    loaded = true;
    notifyListeners();
  }
  void update({String? newTheme, String? newLanguage, int? newDecimals}) {
    if (newTheme != null) theme = newTheme;
    if (newLanguage != null) language = newLanguage;
    if (newDecimals != null) decimals = newDecimals;
    notifyListeners(); saveSoon();
  }
  void setPreference(String key, String value) {
    preferences[key] = value;
    notifyListeners(); saveSoon();
  }
  void setDraft(String page, Map<String, dynamic> values) {
    drafts[page] = values;
    saveSoon();
  }
  void addHistory(String expression, String answer) {
    history.insert(0, {'expression': expression, 'answer': answer});
    if (history.length > 100) history.removeLast();
    notifyListeners(); saveSoon();
  }
  void clearHistory() {history.clear(); notifyListeners(); saveSoon();}
  void removeHistory(int index) {history.removeAt(index); notifyListeners(); saveSoon();}
  void addScenario(String kind, String name, Map<String, dynamic> values) {
    scenarios.insert(0, {'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'kind': kind, 'name': name, 'saved': DateTime.now().toIso8601String(), 'data': values});
    notifyListeners(); saveSoon();
  }
  void removeScenario(String id) {
    scenarios.removeWhere((s) => s['id'] == id); notifyListeners(); saveSoon();
  }
  void reset() {
    theme = 'system'; language = 'nl'; decimals = 2;
    history.clear(); scenarios.clear(); drafts.clear(); preferences.clear();
    preferences.addAll({'bankRate':'32','bankTax':'17.5','bankDays':'31',
      'basicPrice':'39','mediumPrice':'59','proPrice':'79','vatRate':'21'});
    notifyListeners(); saveSoon();
  }
  void saveSoon() {
    _pending?.cancel();
    _pending = Timer(const Duration(milliseconds: 450), persist);
  }
  Future<void> persist() async {
    if (folder == null) return;
    try {
      final json = jsonEncode({'theme': theme, 'language': language, 'decimals': decimals,
        'history': history, 'scenarios': scenarios, 'drafts': drafts,
        'preferences': preferences});
      final target = File('${folder!.path}/kalqo_data.json');
      final temporary = File('${folder!.path}/kalqo_data.tmp');
      await temporary.writeAsString(json, flush: true);
      await temporary.rename(target.path);
    } catch (e) { debugPrint('Failed to persist KALQO data: $e'); }
  }
  @override
  void dispose() { _pending?.cancel(); persist(); super.dispose(); }
}
