/// Arbitrary-size, deterministic 12-decimal-place fixed-point arithmetic.
/// Uses BigInt; values are rounded only when rendered in the UI.
class Dec implements Comparable<Dec> {
  static final BigInt unit = BigInt.from(10).pow(12);
  final BigInt raw;
  const Dec._(this.raw);
  static final Dec zero = Dec._(BigInt.zero);
  static final Dec one = Dec._(unit);
  factory Dec.fromInt(int n) => Dec._(BigInt.from(n) * unit);
  factory Dec.parse(String source) {
    var s = source.trim().replaceAll(RegExp(r'[\s€₺$%]'), '');
    if (s.isEmpty) return zero;
    // Decimal comma is supported, and European grouping is recognized.
    if (s.contains(',') && s.contains('.')) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
        s = s.replaceAll('.', '').replaceAll(',', '.');
      } else {
        s = s.replaceAll(',', '');
      }
    } else if (s.contains(',')) {
      final parts = s.split(',');
      s = parts.length == 2 && parts.last.length == 3 && parts.first.length <= 3
          ? s.replaceAll(',', '')
          : s.replaceAll(',', '.');
    } else if ('.'.allMatches(s).length > 1) {
      s = s.replaceAll('.', '');
    }
    final sign = s.startsWith('-') ? -1 : 1;
    if (s.startsWith('-') || s.startsWith('+')) s = s.substring(1);
    if (!RegExp(r'^\d+(\.\d*)?$').hasMatch(s)) {
      throw FormatException('Invalid decimal: $source');
    }
    final parts = s.split('.');
    final fraction = parts.length > 1 ? parts[1] : '';
    final fraction12 = (fraction + '000000000000').substring(0, 12);
    final fractional = BigInt.parse(fraction12);
    return Dec._((BigInt.parse(parts[0]) * unit + fractional) * BigInt.from(sign));
  }
  factory Dec.of(String input) => Dec.parse(input);
  Dec operator +(Dec b) => Dec._(raw + b.raw);
  Dec operator -(Dec b) => Dec._(raw - b.raw);
  Dec operator -() => Dec._(-raw);
  Dec operator *(Dec b) => Dec._(_round(raw * b.raw, unit));
  Dec operator /(Dec b) {
    if (b.raw == BigInt.zero) throw StateError('Cannot divide by zero');
    return Dec._(_round(raw * unit, b.raw));
  }
  static BigInt _round(BigInt numerator, BigInt denominator) {
    final negative = (numerator.isNegative != denominator.isNegative);
    final n = numerator.abs();
    final d = denominator.abs();
    final result = (n * BigInt.two + d) ~/ (d * BigInt.two);
    return negative ? -result : result;
  }
  Dec pct() => this / Dec.fromInt(100);
  Dec get abs => Dec._(raw.abs());
  Dec get positive => raw.isNegative ? zero : this;
  Dec min(Dec b) => this <= b ? this : b;
  Dec max(Dec b) => this >= b ? this : b;
  double toDouble() => raw.toDouble() / unit.toDouble();
  @override
  int compareTo(Dec other) => raw.compareTo(other.raw);
  bool operator <(Dec b) => compareTo(b) < 0;
  bool operator <=(Dec b) => compareTo(b) <= 0;
  bool operator >(Dec b) => compareTo(b) > 0;
  bool operator >=(Dec b) => compareTo(b) >= 0;
  String toFixed(int places) {
    if (places < 0 || places > 10) throw RangeError('places must be 0..10');
    final divisor = BigInt.from(10).pow(12 - places);
    final scaled = _round(raw, divisor);
    final negative = scaled.isNegative ? '-' : '';
    final digits = scaled.abs().toString().padLeft(places + 1, '0');
    if (places == 0) return '$negative$digits';
    return '$negative${digits.substring(0, digits.length - places)}.${digits.substring(digits.length - places)}';
  }
  String localized({int places = 2, String symbol = '', String language = 'nl'}) {
    final s = toFixed(places);
    final negative = s.startsWith('-');
    final noSign = negative ? s.substring(1) : s;
    final pair = noSign.split('.');
    final european = language != 'en';
    final sep = european ? '.' : ',';
    final integer = pair.first.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => sep);
    final decimal = pair.length > 1 ? '${european ? ',' : '.'}${pair[1]}' : '';
    return '${negative ? '-' : ''}$symbol$integer$decimal';
  }
  @override
  String toString() => toFixed(6);
}

Dec d(num value) => Dec.parse(value.toString());
Dec pct(Dec value, Dec percentage) => value * percentage.pct();
