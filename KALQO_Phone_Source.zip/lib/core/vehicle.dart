import 'dart:convert';
import 'dart:io';

/// Public government registration records only. They are not accident reports.
String normalizeDutchPlate(String text) => text.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

String formatRdwDate(String? raw) {
  if (raw == null || raw.isEmpty) return '—';
  final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.length < 8) return raw;
  return '${digits.substring(6, 8)}-${digits.substring(4, 6)}-${digits.substring(0, 4)}';
}

class VehicleRecord {
  final String identifier, source, make, model, year, bodyType, fuel,
      color, registration, apk, odometerJudgement, odometerYear,
      weight, engine, vin, power, emissions;
  const VehicleRecord({required this.identifier, required this.source,
    this.make = '', this.model = '', this.year = '', this.bodyType = '',
    this.fuel = '', this.color = '', this.registration = '', this.apk = '',
    this.odometerJudgement = '', this.odometerYear = '', this.weight = '',
    this.engine = '', this.vin = '', this.power = '', this.emissions = ''});
  factory VehicleRecord.fromRdw(Map<String, dynamic> json, String plate, {String fuel = ''}) {
    String str(String field) => (json[field] ?? '').toString();
    final date = str('datum_eerste_toelating');
    return VehicleRecord(identifier: plate, source: 'RDW Open Data',
      make: str('merk'), model: str('handelsbenaming'),
      year: date.length >= 4 ? date.substring(0, 4) : '',
      bodyType: str('inrichting'), fuel: fuel,
      color: str('eerste_kleur'), registration: formatRdwDate(date),
      apk: formatRdwDate(str('vervaldatum_apk')),
      odometerJudgement: str('tellerstandoordeel'),
      odometerYear: str('jaar_laatste_registratie_tellerstand'),
      weight: str('massa_rijklaar'), engine: str('cilinderinhoud'),
      power: str('vermogen_massarijklaar'),
      emissions: str('zuinigheidsclassificatie'));
  }
  factory VehicleRecord.fromNhtsa(Map<String, dynamic> json, String vin) {
    String str(String key) => (json[key] ?? '').toString();
    return VehicleRecord(identifier: vin, source: 'NHTSA vPIC · VIN decoder',
      vin: vin, make: str('Make'), model: str('Model'), year: str('ModelYear'),
      bodyType: str('BodyClass'), fuel: str('FuelTypePrimary'),
      engine: str('DisplacementL'), power: str('EngineHP'));
  }
}

class VehicleLookupException implements Exception {
  final String message;
  const VehicleLookupException(this.message);
  @override String toString() => message;
}

class VehicleApi {
  static Future<dynamic> _load(Uri uri) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.acceptHeader, 'application/json');
      final res = await req.close().timeout(const Duration(seconds: 18));
      if (res.statusCode != 200) throw const VehicleLookupException('Vehicle service unavailable. Try again later.');
      final text = await res.transform(utf8.decoder).join();
      return jsonDecode(text);
    } on SocketException {
      throw const VehicleLookupException('No internet connection. Check Wi-Fi or mobile data.');
    } on HandshakeException {
      throw const VehicleLookupException('Secure connection to the vehicle service failed.');
    } on FormatException {
      throw const VehicleLookupException('Vehicle service returned unexpected data.');
    } finally { client.close(force: true); }
  }

  static Future<VehicleRecord> dutchPlate(String raw) async {
    final plate = normalizeDutchPlate(raw);
    if (plate.length < 5 || plate.length > 8) {
      throw const VehicleLookupException('Enter a valid Dutch registration plate.');
    }
    final uri = Uri.https('opendata.rdw.nl', '/resource/m9d7-ebf2.json', {'kenteken': plate});
    final data = await _load(uri);
    if (data is! List || data.isEmpty || data.first is! Map) {
      throw const VehicleLookupException('No matching RDW registration was found.');
    }
    final vehicle = Map<String, dynamic>.from(data.first as Map);
    String fuel = '';
    try {
      final fuelUri = Uri.https('opendata.rdw.nl','/resource/8ys7-d773.json',{'kenteken':plate});
      final fuelData = await _load(fuelUri);
      if (fuelData is List && fuelData.isNotEmpty && fuelData.first is Map) {
        fuel = '${fuelData.first['brandstof_omschrijving'] ?? ''}';
      }
    } catch (_) { /* Fuel is optional. Never fail the vehicle query for this. */ }
    return VehicleRecord.fromRdw(vehicle, plate, fuel: fuel);
  }

  /// US government API is VIN-only. A license plate cannot be decoded here.
  static Future<VehicleRecord> americanVin(String raw) async {
    final vin = raw.trim().toUpperCase();
    if (!RegExp(r'^[A-HJ-NPR-Z0-9]{17}$').hasMatch(vin)) {
      throw const VehicleLookupException('Enter a 17-character VIN, not a US license plate.');
    }
    final uri = Uri.https('vpic.nhtsa.dot.gov',
      '/api/vehicles/DecodeVinValues/$vin', {'format':'json'});
    final data = await _load(uri);
    if (data is! Map || data['Results'] is! List || (data['Results'] as List).isEmpty) {
      throw const VehicleLookupException('No VIN data was returned.');
    }
    final result = Map<String, dynamic>.from((data['Results'] as List).first as Map);
    if ((result['Make'] ?? '').toString().isEmpty) {
      throw const VehicleLookupException('VIN was not recognized by the NHTSA database.');
    }
    return VehicleRecord.fromNhtsa(result, vin);
  }
}
