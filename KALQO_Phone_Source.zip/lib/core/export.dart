import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'storage.dart';

String _csv(String s) => '"${s.replaceAll('"', '""')}"';

class Reports {
  static Future<String> saveBackup(AppStore store) => _share(
    'kalqo_backup_${DateTime.now().millisecondsSinceEpoch}.json',
    utf8.encode(const JsonEncoder.withIndent('  ').convert({
      'theme': store.theme, 'language': store.language, 'decimals': store.decimals,
      'history': store.history, 'scenarios': store.scenarios,
      'drafts': store.drafts, 'preferences': store.preferences,
    })), 'application/json', store);

  static Future<String> saveCsv(String name, List<List<String>> rows, AppStore store) async {
    final csv = rows.map((r) => r.map(_csv).join(';')).join('\r\n');
    return _share(name, utf8.encode('\ufeff$csv'), 'text/csv', store);
  }

  static Future<String> savePdf(String name, List<String> lines, AppStore store) async {
    final pages = <List<String>>[];
    for (var start = 0; start < lines.length; start += 42) {
      pages.add(lines.skip(start).take(42).toList());
    }
    if (pages.isEmpty) pages.add(['KALQO']);
    final bytes = _basicPdf(pages);
    return _share(name, bytes, 'application/pdf', store);
  }

  static Future<String> _share(String name, List<int> bytes, String mime, AppStore store) async {
    final base = store.folder ?? Directory.systemTemp;
    final out = Directory('${base.path}/reports');
    await out.create(recursive: true);
    final safe = name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final f = File('${out.path}/$safe');
    await f.writeAsBytes(bytes, flush: true);
    try {
      await androidBridge.invokeMethod('shareFile', {'path': f.path, 'mime': mime});
    } on MissingPluginException catch (_) { /* Desktop: file saved */ }
    return f.path;
  }

  // Minimal PDF 1.4 implementation. Built-in Helvetica supports ASCII only;
  // unsupported characters are replaced. No external package or internet needed.
  static List<int> _basicPdf(List<List<String>> pages) {
    final objects = <String>[];
    void add(String s) => objects.add(s);
    add('<< /Type /Catalog /Pages 2 0 R >>');
    final ids = List.generate(pages.length, (i) => 4 + i * 2);
    add('<< /Type /Pages /Kids [${ids.map((id) => '$id 0 R').join(' ')}] /Count ${pages.length} >>');
    add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
    for (var i = 0; i < pages.length; i++) {
      final pg = pages[i];
      final stream = StringBuffer('BT /F1 11 Tf 42 790 Td 15 TL\n');
      for (final row in pg) {
        final sanitized = row.replaceAll(RegExp(r'[^\x20-\x7E]'), '?')
            .replaceAll('\\', '\\\\').replaceAll('(', '\\(').replaceAll(')', '\\)');
        stream.writeln('($sanitized) Tj T*');
      }
      stream.write('ET');
      final body = stream.toString();
      add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${ids[i]+1} 0 R >>');
      add('<< /Length ${latin1.encode(body).length} >>\nstream\n$body\nendstream');
    }
    final out = BytesBuilder();
    void write(String x) => out.add(latin1.encode(x));
    write('%PDF-1.4\n');
    final offsets = <int>[0];
    for (var i = 0; i < objects.length; i++) {
      offsets.add(out.length);
      write('${i + 1} 0 obj\n${objects[i]}\nendobj\n');
    }
    final startXref = out.length;
    write('xref\n0 ${objects.length + 1}\n0000000000 65535 f \n');
    for (final offset in offsets.skip(1)) {
      write('${offset.toString().padLeft(10, '0')} 00000 n \n');
    }
    write('trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n$startXref\n%%EOF');
    return out.toBytes();
  }
}
