import 'decimal.dart';

/// Recursive descent expression evaluator. Supports unary +/-, precedence,
/// postfix percent, parentheses, and explicit divide-by-zero handling.
class ExpressionCalculator {
  String _input = '';
  int _position = 0;
  Dec evaluate(String text) {
    _input = text.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-').replaceAll(',', '.');
    _position = 0;
    final value = _expression();
    _spaces();
    if (_position != _input.length) throw FormatException('Unexpected character');
    return value;
  }
  Dec _expression() {
    var left = _term();
    while (true) {
      _spaces();
      if (_eat('+')) left += _term();
      else if (_eat('-')) left -= _term();
      else return left;
    }
  }
  Dec _term() {
    var left = _factor();
    while (true) {
      _spaces();
      if (_eat('*')) left *= _factor();
      else if (_eat('/')) left /= _factor();
      else return left;
    }
  }
  Dec _factor() {
    _spaces();
    if (_eat('-')) return -_factor();
    if (_eat('+')) return _factor();
    Dec result;
    if (_eat('(')) {
      result = _expression();
      if (!_eat(')')) throw FormatException('Missing closing parenthesis');
    } else {
      final start = _position;
      while (_position < _input.length && RegExp(r'[0-9.]').hasMatch(_input[_position])) {
        _position++;
      }
      if (start == _position) throw FormatException('Expected number');
      result = Dec.parse(_input.substring(start, _position));
    }
    while (_eat('%')) result = result.pct();
    return result;
  }
  void _spaces() {
    while (_position < _input.length && _input[_position].trim().isEmpty) _position++;
  }
  bool _eat(String token) {
    _spaces();
    if (_position < _input.length && _input[_position] == token) {
      _position++; return true;
    }
    return false;
  }
}
