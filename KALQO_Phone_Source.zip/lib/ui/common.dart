import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/decimal.dart';
import '../core/storage.dart';

const accent = Color(0xFF3789FF);
const ink = Color(0xFF181D25);

String tr(AppStore store, String en, String nl, String turkish) =>
  store.language == 'tr' ? turkish : store.language == 'nl' ? nl : en;

String money(Dec amount, AppStore store, {String symbol = '€'}) =>
    amount.localized(places: store.decimals, symbol: symbol, language: store.language);

ThemeData appTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final base = ThemeData(useMaterial3: true, brightness: brightness,
    scaffoldBackgroundColor: dark ? const Color(0xFF101216) : const Color(0xFFF5F6F8),
    colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: brightness),
    appBarTheme: AppBarTheme(backgroundColor: dark ? const Color(0xFF101216) : const Color(0xFFF5F6F8),
      elevation: 0, surfaceTintColor: Colors.transparent),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: accent, foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16))),
    inputDecorationTheme: InputDecorationTheme(filled: true,
      fillColor: dark ? const Color(0xFF24272F) : const Color(0xFFF0F2F5),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13),
        borderSide: const BorderSide(color: accent, width: 1.4)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 15)),
  );
  return base.copyWith(textTheme: base.textTheme.apply(fontFamily: 'sans-serif',
    bodyColor: dark ? Colors.white : ink, displayColor: dark ? Colors.white : ink));
}

class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const KCard({super.key, required this.child, this.padding = const EdgeInsets.all(18)});
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(width: double.infinity, padding: padding,
      decoration: BoxDecoration(color: dark ? const Color(0xFF1C2027) : Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: dark ? const Color(0xFF303640) : const Color(0xFFEAECEF))),
      child: child);
  }
}

class SectionHead extends StatelessWidget {
  final String title;
  final Widget? action;
  const SectionHead(this.title, {super.key, this.action});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 11, top: 12),
    child: Row(children: [Expanded(child: Text(title,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -.5))),
      if (action != null) action!]));
}

class NumberField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final VoidCallback onChanged;
  final String? suffix;
  final bool integer;
  const NumberField({super.key, required this.label, required this.controller,
    required this.onChanged, this.suffix, this.integer = false});
  @override
  Widget build(BuildContext context) => TextField(
    controller: controller, onChanged: (_) => onChanged(),
    keyboardType: TextInputType.numberWithOptions(decimal: !integer, signed: false),
    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(integer ? r'[0-9]' : r'[0-9.,]'))],
    decoration: InputDecoration(labelText: label, suffixText: suffix),
    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16));
}

class Metric extends StatelessWidget {
  final String label, value;
  final bool highlighted;
  final IconData? icon;
  const Metric({super.key, required this.label, required this.value, this.highlighted = false, this.icon});
  @override
  Widget build(BuildContext context) {
    return KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (icon != null) ...[Icon(icon, color: highlighted ? accent : Theme.of(context).hintColor, size: 22), const SizedBox(height: 14)],
      Text(label.toUpperCase(), style: TextStyle(fontSize: 10.5, letterSpacing: 1.1,
        fontWeight: FontWeight.w700, color: Theme.of(context).hintColor)),
      const SizedBox(height: 9),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
        child: Text(value, maxLines: 1, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800,
          letterSpacing: -.7, color: highlighted ? accent : null)))
    ]));
  }
}

class MetricGrid extends StatelessWidget {
  final List<Metric> children;
  const MetricGrid({super.key, required this.children});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, size) {
    final width = size.maxWidth;
    return Wrap(spacing: 10, runSpacing: 10, children: children.map((e) =>
      SizedBox(width: width > 650 ? (width - 20) / 3 : (width - 10) / 2, child: e)).toList());
  });
}

class Hint extends StatelessWidget {
  final String text;
  const Hint(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 8),
    child: Text(text, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12.5, height: 1.5)));
}

class ChartLine extends StatelessWidget {
  final List<double> values;
  final double height;
  const ChartLine({super.key, required this.values, this.height = 148});
  @override
  Widget build(BuildContext context) => SizedBox(height: height, width: double.infinity,
    child: CustomPaint(painter: _ChartPainter(values: values, grid: Theme.of(context).dividerColor)));
}
class _ChartPainter extends CustomPainter {
  final List<double> values;
  final Color grid;
  _ChartPainter({required this.values, required this.grid});
  @override
  void paint(Canvas canvas, Size size) {
    final axis = Paint()..color = grid.withValues(alpha: .35)..strokeWidth = 1;
    for (var y = 1; y <= 3; y++) {
      canvas.drawLine(Offset(0, size.height * y / 4), Offset(size.width, size.height * y / 4), axis);
    }
    if (values.isEmpty) return;
    final lo = values.reduce((a, b) => a < b ? a : b);
    final hi = values.reduce((a, b) => a > b ? a : b);
    final range = (hi - lo).abs() < .0001 ? 1.0 : hi - lo;
    Offset point(int i) => Offset(values.length == 1 ? size.width / 2 : i * size.width / (values.length - 1),
      size.height - 10 - (values[i] - lo) / range * (size.height - 20));
    final p = Path()..moveTo(point(0).dx, point(0).dy);
    for (var i = 1; i < values.length; i++) p.lineTo(point(i).dx, point(i).dy);
    canvas.drawPath(p, Paint()..color = accent..strokeWidth = 2.8..style = PaintingStyle.stroke..strokeCap = StrokeCap.round);
    for (var i = 0; i < values.length; i++) {
      canvas.drawCircle(point(i), 3, Paint()..color = accent);
    }
  }
  @override
  bool shouldRepaint(covariant _ChartPainter old) => old.values != values || old.grid != grid;
}

Future<String?> askName(BuildContext context, String title) async {
  final field = TextEditingController();
  final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
    title: Text(title), content: TextField(controller: field, autofocus: true,
      decoration: const InputDecoration(hintText: 'Scenario name')),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: () => Navigator.pop(context, field.text.trim()), child: const Text('Save'))]));
  field.dispose();
  return result?.isEmpty == true ? null : result;
}

void notice(BuildContext context, String text) {
  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}
