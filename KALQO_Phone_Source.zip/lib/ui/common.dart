import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/decimal.dart';
import '../core/storage.dart';

const accent = Color(0xFF3789FF);
const ink = Color(0xFF181D25);

String tr(AppStore store, String en, String nl, String turkish) =>
  store.language == 'tr' ? turkish : store.language == 'nl' ? nl : en;

String money(Dec amount, AppStore store, {String symbol = '€'}) =>
    amount.localized(places: store.decimals, symbol: symbol, language: store.language);


Color surface(BuildContext context) => Theme.of(context).brightness == Brightness.dark
    ? const Color(0xFF191E27) : const Color(0xFFFFFFFF);
Color muted(BuildContext context) => Theme.of(context).brightness == Brightness.dark
    ? const Color(0xFF959BAA) : const Color(0xFF6C7280);

ThemeData appTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final background = dark ? const Color(0xFF101319) : const Color(0xFFF7F8FA);
  final foreground = dark ? const Color(0xFFF7F8FD) : const Color(0xFF161B24);
  final base = ThemeData(
    useMaterial3: true, brightness: brightness,
    scaffoldBackgroundColor: background,
    colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: brightness,
      surface: background),
    appBarTheme: AppBarTheme(backgroundColor: background, elevation: 0,
      surfaceTintColor: Colors.transparent),
    dividerColor: dark ? const Color(0xFF30353F) : const Color(0xFFE6E8EC),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: accent, foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
      side: BorderSide(color: dark ? const Color(0xFF444B57) : const Color(0xFFD7DCE4)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16))),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0xFF222831) : const Color(0xFFF0F2F6),
      floatingLabelBehavior: FloatingLabelBehavior.auto,
      labelStyle: TextStyle(color: dark ? const Color(0xFF9CA3B1) : const Color(0xFF69717D),fontSize:13),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: accent, width: 1.3)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 17)),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) =>
        states.contains(WidgetState.selected) ? accent : null)),
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(fontFamily: 'sans-serif',
      bodyColor: foreground, displayColor: foreground),
  );
}

/// One quiet surface for INPUTS. Use open sections for results, not nested cards.
class KCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const KCard({super.key, required this.child, this.padding = const EdgeInsets.all(20)});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity, padding: padding,
    decoration: BoxDecoration(color: surface(context),
      borderRadius: BorderRadius.circular(23)),
    child: child);
}

class SectionHead extends StatelessWidget {
  final String title;
  final Widget? action;
  const SectionHead(this.title, {super.key, this.action});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 15, top: 29),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 19,
        fontWeight: FontWeight.w700, letterSpacing: -.45))),
      if (action != null) action!,
    ]));
}

class Kicker extends StatelessWidget {
  final String label;
  const Kicker(this.label, {super.key});
  @override
  Widget build(BuildContext context) => Text(label.toUpperCase(),
    style: TextStyle(color: muted(context), fontWeight: FontWeight.w700,
      letterSpacing: 1.5, fontSize: 10.5));
}

class HeroFigure extends StatelessWidget {
  final String caption, value;
  final String? supporting;
  final Color? color;
  const HeroFigure({super.key, required this.caption, required this.value, this.supporting, this.color});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Kicker(caption), const SizedBox(height: 9),
      SizedBox(width: double.infinity, child: FittedBox(fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Text(value, maxLines: 1, style: TextStyle(fontSize: 44,
          fontWeight: FontWeight.w700, letterSpacing: -1.8, color: color)))),
      if (supporting != null) ...[
        const SizedBox(height: 5),
        Text(supporting!,style: TextStyle(fontSize: 13,color: muted(context)))],
    ]);
}

class InlineStat extends StatelessWidget {
  final String label, value;
  final bool highlight;
  const InlineStat({super.key, required this.label, required this.value, this.highlight=false});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,children:[
      Text(label, style: TextStyle(fontSize: 12, color: muted(context))),
      const SizedBox(height: 6),
      FittedBox(fit: BoxFit.scaleDown,alignment: Alignment.centerLeft,
        child: Text(value,maxLines: 1, style: TextStyle(fontSize: 16.5,
          fontWeight: FontWeight.w700, letterSpacing: -.45,
          color: highlight ? accent : null))),
    ]);
}

class NumberField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final VoidCallback onChanged;
  final String? suffix;
  final bool integer;
  const NumberField({super.key, required this.label, required this.controller,
    required this.onChanged, this.suffix, this.integer = false});
  @override
  Widget build(BuildContext context) => TextField(
    controller: controller, onChanged: (_) => onChanged(),
    keyboardType: TextInputType.numberWithOptions(decimal: !integer, signed: false),
    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(integer ? r'[0-9]' : r'[0-9.,]'))],
    decoration: InputDecoration(labelText: label, suffixText: suffix),
    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16));
}

/// Borderless information tiles, no card-per-number dashboard.
class Metric extends StatelessWidget {
  final String label, value;
  final bool highlighted;
  final IconData? icon;
  const Metric({super.key, required this.label, required this.value, this.highlighted = false, this.icon});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, maxLines: 2, style: TextStyle(
        fontSize: 12, height: 1.4, color: muted(context))),
      const SizedBox(height: 8),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
        child: Text(value, maxLines: 1, style: TextStyle(fontSize: 20,
          fontWeight: FontWeight.w700, letterSpacing: -.7,
          color: highlighted ? accent : null))),
    ]));
}
class MetricGrid extends StatelessWidget {
  final List<Metric> children;
  const MetricGrid({super.key, required this.children});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, size) {
    final width = size.maxWidth;
    return Wrap(spacing: 22, runSpacing: 22, children: children.map((e) =>
      SizedBox(width: width > 650 ? (width - 44) / 3 : (width - 22) / 2, child: e)).toList());
  });
}
class Hint extends StatelessWidget {
  final String text;
  const Hint(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 7),
    child: Text(text, style: TextStyle(color: muted(context), fontSize: 12.5, height: 1.6)));
}
class ChartLine extends StatelessWidget {
  final List<double> values;
  final double height;
  const ChartLine({super.key, required this.values, this.height = 148});
  @override
  Widget build(BuildContext context) => SizedBox(height: height, width: double.infinity,
    child: CustomPaint(painter: _ChartPainter(values: values, grid: Theme.of(context).dividerColor)));
}
class _ChartPainter extends CustomPainter {
  final List<double> values;
  final Color grid;
  _ChartPainter({required this.values, required this.grid});
  @override
  void paint(Canvas canvas, Size size) {
    final axis = Paint()..color = grid.withValues(alpha: .35)..strokeWidth = 1;
    for (var y = 1; y <= 3; y++) {
      canvas.drawLine(Offset(0, size.height * y / 4), Offset(size.width, size.height * y / 4), axis);
    }
    if (values.isEmpty) return;
    final lo = values.reduce((a, b) => a < b ? a : b);
    final hi = values.reduce((a, b) => a > b ? a : b);
    final range = (hi - lo).abs() < .0001 ? 1.0 : hi - lo;
    Offset point(int i) => Offset(values.length == 1 ? size.width / 2 : i * size.width / (values.length - 1),
      size.height - 10 - (values[i] - lo) / range * (size.height - 20));
    final p = Path()..moveTo(point(0).dx, point(0).dy);
    for (var i = 1; i < values.length; i++) p.lineTo(point(i).dx, point(i).dy);
    canvas.drawPath(p, Paint()..color = accent..strokeWidth = 2.8..style = PaintingStyle.stroke..strokeCap = StrokeCap.round);
    for (var i = 0; i < values.length; i++) {
      canvas.drawCircle(point(i), 3, Paint()..color = accent);
    }
  }
  @override
  bool shouldRepaint(covariant _ChartPainter old) => old.values != values || old.grid != grid;
}

Future<String?> askName(BuildContext context, String title) async {
  final field = TextEditingController();
  final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
    title: Text(title), content: TextField(controller: field, autofocus: true,
      decoration: const InputDecoration(hintText: 'Scenario name')),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: () => Navigator.pop(context, field.text.trim()), child: const Text('Save'))]));
  field.dispose();
  return result?.isEmpty == true ? null : result;
}

void notice(BuildContext context, String text) {
  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}
