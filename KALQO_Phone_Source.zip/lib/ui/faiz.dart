import 'package:flutter/material.dart';
import '../core/decimal.dart';
import '../core/finance.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class FaizPage extends StatefulWidget {
  final AppStore store;
  const FaizPage({super.key, required this.store});
  @override
  State<FaizPage> createState() => _FaizPageState();
}
class _FaizPageState extends State<FaizPage> {
  final principal = TextEditingController(text: '100000');
  final rate = TextEditingController(text: '32');
  final days = TextEditingController(text: '31');
  final stopaj = TextEditingController(text: '17.5');
  final periods = TextEditingController(text: '12');
  final basis = TextEditingController(text: '365');
  bool reinvest = true, calendar = false;
  String currency = 'TRY';
  DateTime from = DateTime(2026, 1, 1);
  bool restored = false;
  String get symbol => {'TRY':'₺', 'EUR':'€', 'USD':'\$'}[currency] ?? '₺';
  String fmt(Dec x) => money(x, widget.store, symbol: symbol);
  void restore(Map<String, dynamic> m) {
    principal.text = '${m['principal'] ?? '100000'}';
    rate.text = '${m['rate'] ?? '32'}';
    days.text = '${m['days'] ?? '31'}';
    stopaj.text = '${m['tax'] ?? '17.5'}';
    periods.text = '${m['periods'] ?? '12'}';
    basis.text = '${m['basis'] ?? '365'}';
    currency = '${m['currency'] ?? 'TRY'}';
    reinvest = m['reinvest'] != false;
    calendar = m['calendar'] == true;
    from = DateTime.tryParse('${m['start'] ?? ''}') ?? DateTime(2026, 1, 1);
  }
  Map<String, dynamic> snapshot() => {'principal': principal.text, 'rate': rate.text,
    'days': days.text, 'tax': stopaj.text, 'periods': periods.text, 'basis': basis.text,
    'currency': currency, 'reinvest': reinvest, 'calendar': calendar, 'start': from.toIso8601String()};
  void changed() { widget.store.setDraft('faiz', snapshot()); setState(() {}); }
  InterestResult? get result {
    try {
      return calculateInterest(InterestInput(principal: Dec.parse(principal.text),
        annualPercent: Dec.parse(rate.text), taxPercent: Dec.parse(stopaj.text),
        days: int.parse(days.text), periods: int.parse(periods.text),
        basis: int.parse(basis.text), reinvest: reinvest, calendarMode: calendar, startDate: from));
    } catch (_) {return null;}
  }
  @override
  void initState() {
    super.initState();
    rate.text = widget.store.preferences['bankRate'] ?? '32';
    stopaj.text = widget.store.preferences['bankTax'] ?? '17.5';
    days.text = widget.store.preferences['bankDays'] ?? '31';
  }
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      restored = true;
      final m = widget.store.drafts['faiz'];
      if (m is Map) restore(Map<String, dynamic>.from(m));
    }
  }
  @override
  void dispose() {
    for (final ctrl in [principal,rate,days,stopaj,periods,basis]) ctrl.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final r = result;
    final first = r?.rows.isNotEmpty == true ? r!.rows.first : null;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 36), children: [
      const SizedBox(height: 10),
      const Text('Faiz Hesaplama', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 29, letterSpacing: -.9)),
      Hint(tr(widget.store, 'Turkish deposit interest · offline projections',
        'Turkse spaarrente · offline berekeningen', 'Vadeli mevduat faiz hesaplama')),
      const SizedBox(height: 8),
      KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('INVESTMENT', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: accent, letterSpacing: 1.3)),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(key: ValueKey(currency), initialValue: currency,
          decoration: const InputDecoration(labelText: 'Currency'),
          items: const [DropdownMenuItem(value: 'TRY', child: Text('TRY · Turkish lira')),
            DropdownMenuItem(value: 'EUR', child: Text('EUR · Euro')),
            DropdownMenuItem(value: 'USD', child: Text('USD · US dollar'))],
          onChanged: (v) { if (v != null) {currency = v; changed();} }),
        const SizedBox(height: 10),
        NumberField(label: 'Anapara / Initial deposit', controller: principal, onChanged: changed, suffix: symbol),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: NumberField(label: 'Annual interest', controller: rate,
          onChanged: changed, suffix: '%')), const SizedBox(width: 10),
          Expanded(child: NumberField(label: 'Stopaj tax', controller: stopaj, onChanged: changed, suffix: '%'))]),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: NumberField(label: 'Term days', controller: days,
          onChanged: changed, suffix: 'days', integer: true)), const SizedBox(width: 10),
          Expanded(child: NumberField(label: 'Periods', controller: periods,
            onChanged: changed, integer: true))]),
        const SizedBox(height: 10),
        NumberField(label: 'Annual day-count basis', controller: basis, onChanged: changed,
          suffix: 'days', integer: true),
        const SizedBox(height: 10),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: reinvest,
          title: const Text('Reinvest net interest'), subtitle: const Text('Off: interest paid out, principal stays fixed'),
          onChanged: (v) {reinvest=v; changed();}),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: calendar,
          title: const Text('Actual calendar months'), subtitle: const Text('Off: fixed number of days per period'),
          onChanged: (v) {calendar=v; changed();}),
        if (calendar) OutlinedButton.icon(onPressed: () async {
          final date = await showDatePicker(context: context, initialDate: from,
            firstDate: DateTime(2000), lastDate: DateTime(2100));
          if (date != null) {from = date; changed();}
        }, icon: const Icon(Icons.calendar_month), label: Text('Month series starts ${from.year}-${from.month.toString().padLeft(2,'0')}')),
      ])),
      const SectionHead('Your returns'),
      if (r == null) const KCard(child: Text('Please enter valid amounts, percentages, and periods (1–600).'))
      else ...[
        MetricGrid(children: [
          Metric(label: 'Gross interest · first period', value: fmt(first!.gross)),
          Metric(label: 'Stopaj · first period', value: fmt(first.tax)),
          Metric(label: 'Net earned · first period', value: fmt(first.net), highlighted: true),
          Metric(label: 'All periods · net earned', value: fmt(r.totalNet), highlighted: true),
          Metric(label: 'All periods · total tax', value: fmt(r.totalTax)),
          Metric(label: 'Principal balance', value: fmt(r.closingBalance)),
        ]),
        const SizedBox(height: 14),
        KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('BALANCE EVOLUTION', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800,
            color: accent, letterSpacing: 1.3)), const SizedBox(height: 16),
          ChartLine(values: [Dec.parse(principal.text).toDouble(),
            ...r.rows.map((e) => (reinvest ? e.ending : e.starting + e.accumulated).toDouble())]),
          const SizedBox(height: 9),
          Text('Total net earned: ${fmt(r.totalNet)}',
            style: const TextStyle(fontSize: 12, color: accent)),
        ])),
        const SectionHead('Period breakdown'),
        ...r.rows.map((e) => Padding(padding: const EdgeInsets.only(bottom: 8),
          child: KCard(padding: const EdgeInsets.all(0), child: ExpansionTile(
            shape: const Border(), collapsedShape: const Border(),
            title: Text('Period ${e.period}  ·  ${e.days} days', style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('Net ${fmt(e.net)}'),
            trailing: Text(fmt(e.ending), style: const TextStyle(fontWeight: FontWeight.w800)),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              _line('Starting balance', fmt(e.starting)),
              _line('Gross interest', fmt(e.gross)),
              _line('Withholding tax', fmt(e.tax)),
              _line('Net earned', fmt(e.net)),
              _line('Cumulative earnings', fmt(e.accumulated)),
            ])))),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.table_rows_outlined),
          label: const Text('Export CSV'), onPressed: () => export(false, r))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.icon(icon: const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('Share PDF'), onPressed: () => export(true, r)))]),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: saveScenario, icon: const Icon(Icons.bookmark_add_outlined),
          label: const Text('Save scenario')),
        const SizedBox(height: 6),
        OutlinedButton.icon(onPressed: scenarios, icon: const Icon(Icons.folder_open_outlined),
          label: const Text('Saved scenarios')),
      ],
      const SizedBox(height: 16),
      const Hint('Forecast only. Turkish stopaj varies by deposit, currency and term. Dutch residents may also have Dutch tax obligations. Check current bank rates and applicable tax rules.'),
    ]);
  }
  Widget _line(String title, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [Expanded(child: Text(title)), Text(value, style: const TextStyle(fontWeight: FontWeight.w700))]));
  Future<void> export(bool pdf, InterestResult r) async {
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final table = [<String>['Period','Days','Starting','Gross','Tax','Net','Ending'],
      ...r.rows.map((e) => [e.period.toString(), e.days.toString(), e.starting.toFixed(2),
        e.gross.toFixed(2), e.tax.toFixed(2), e.net.toFixed(2), e.ending.toFixed(2)])];
    try {
      if (pdf) {
        await Reports.savePdf('kalqo_faiz_$stamp.pdf', [
          'KALQO / FAIZ REPORT', 'Currency: $currency',
          'Principal: ${principal.text}', 'Interest rate: ${rate.text}% annual',
          'Term days: ${days.text}; periods: ${periods.text}',
          'Withholding tax: ${stopaj.text}%', 'Gross total: ${r.totalGross.toFixed(2)}',
          'Tax total: ${r.totalTax.toFixed(2)}', 'Net earned: ${r.totalNet.toFixed(2)}',
          'Ending principal: ${r.closingBalance.toFixed(2)}', '',
          ...table.map((row) => row.join(' | ')), '',
          'Estimates only; cross-border tax obligations excluded.'], widget.store);
      } else {
        await Reports.saveCsv('kalqo_faiz_$stamp.csv', table, widget.store);
      }
      if (mounted) notice(context, 'Report saved / share options opened');
    } catch (e) {if (mounted) notice(context, 'Export failed: $e');}
  }
  Future<void> saveScenario() async {
    final name = await askName(context, 'Save interest scenario');
    if (name != null) {widget.store.addScenario('faiz', name, snapshot()); if (mounted) notice(context, 'Scenario saved');}
  }
  void scenarios() {
    final entries = widget.store.scenarios.where((s) => s['kind'] == 'faiz').toList();
    showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (ctx) => SafeArea(
      child: ListView(shrinkWrap: true, children: [const ListTile(title: Text('Saved interest scenarios',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
        if (entries.isEmpty) const ListTile(title: Text('No saved scenarios')),
        ...entries.map((s) => ListTile(title: Text('${s['name']}'), subtitle: Text('${s['saved']}'.split('T').first),
          onTap: () {restore(Map<String, dynamic>.from(s['data'] as Map)); changed(); Navigator.pop(ctx);},
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () {
            widget.store.removeScenario('${s['id']}'); Navigator.pop(ctx); scenarios();})))])));
  }
}
