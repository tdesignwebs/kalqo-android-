import 'package:flutter/material.dart';
import '../core/decimal.dart';
import '../core/finance.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class FaizPage extends StatefulWidget {
  final AppStore store;
  const FaizPage({super.key, required this.store});
  @override
  State<FaizPage> createState() => _FaizPageState();
}
class _FaizPageState extends State<FaizPage> {
  final principal = TextEditingController(text: '100000');
  final rate = TextEditingController(text: '32');
  final days = TextEditingController(text: '31');
  final stopaj = TextEditingController(text: '17.5');
  final periods = TextEditingController(text: '12');
  final basis = TextEditingController(text: '365');
  bool reinvest = true, calendar = false;
  String currency = 'TRY';
  DateTime from = DateTime(2026, 1, 1);
  bool restored = false;
  String get symbol => {'TRY':'₺', 'EUR':'€', 'USD':'\$'}[currency] ?? '₺';
  String fmt(Dec x) => money(x, widget.store, symbol: symbol);
  void restore(Map<String, dynamic> m) {
    principal.text = '${m['principal'] ?? '100000'}';
    rate.text = '${m['rate'] ?? '32'}';
    days.text = '${m['days'] ?? '31'}';
    stopaj.text = '${m['tax'] ?? '17.5'}';
    periods.text = '${m['periods'] ?? '12'}';
    basis.text = '${m['basis'] ?? '365'}';
    currency = '${m['currency'] ?? 'TRY'}';
    reinvest = m['reinvest'] != false;
    calendar = m['calendar'] == true;
    from = DateTime.tryParse('${m['start'] ?? ''}') ?? DateTime(2026, 1, 1);
  }
  Map<String, dynamic> snapshot() => {'principal': principal.text, 'rate': rate.text,
    'days': days.text, 'tax': stopaj.text, 'periods': periods.text, 'basis': basis.text,
    'currency': currency, 'reinvest': reinvest, 'calendar': calendar, 'start': from.toIso8601String()};
  void changed() { widget.store.setDraft('faiz', snapshot()); setState(() {}); }
  InterestResult? get result {
    try {
      return calculateInterest(InterestInput(principal: Dec.parse(principal.text),
        annualPercent: Dec.parse(rate.text), taxPercent: Dec.parse(stopaj.text),
        days: int.parse(days.text), periods: int.parse(periods.text),
        basis: int.parse(basis.text), reinvest: reinvest, calendarMode: calendar, startDate: from));
    } catch (_) {return null;}
  }
  @override
  void initState() {
    super.initState();
    rate.text = widget.store.preferences['bankRate'] ?? '32';
    stopaj.text = widget.store.preferences['bankTax'] ?? '17.5';
    days.text = widget.store.preferences['bankDays'] ?? '31';
  }
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      restored = true;
      final m = widget.store.drafts['faiz'];
      if (m is Map) restore(Map<String, dynamic>.from(m));
    }
  }
  @override
  void dispose() {
    for (final ctrl in [principal,rate,days,stopaj,periods,basis]) ctrl.dispose();
    super.dispose();
  }

  bool showOptions = false;
  @override
  Widget build(BuildContext context) {
    final r = result;
    final heading = tr(widget.store, 'Interest', 'Rente', 'Faiz');
    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(24, 21, 24, 44),
      children: [
        Row(children: [
          Expanded(child: Text(heading, style: const TextStyle(
            fontSize: 29, fontWeight: FontWeight.w700, letterSpacing: -1.2))),
          IconButton(tooltip: 'Saved scenarios', onPressed: scenarios,
            icon: const Icon(Icons.bookmarks_outlined)),
        ]),
        const SizedBox(height: 31),
        if (r != null) ...[
          HeroFigure(
            caption: tr(widget.store, 'Total net interest', 'Totale netto rente', 'Toplam net faiz'),
            value: fmt(r.totalNet),
            supporting: '${periods.text} × ${calendar ? 'calendar months' : '${days.text} days'} · ${rate.text}% annual'),
          const SizedBox(height: 25),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: InlineStat(label: tr(widget.store,'Final balance','Eindsaldo','Son bakiye'),
              value: fmt(r.closingBalance))),
            const SizedBox(width: 16),
            Expanded(child: InlineStat(label: 'Stopaj', value: fmt(r.totalTax))),
          ]),
          const SizedBox(height: 28),
          Divider(height: 1, color: Theme.of(context).dividerColor),
        ] else ...[
          const Hint('Enter a valid deposit, rate, and term.'),
        ],
        const SectionHead('Investment'),
        KCard(child: Column(children: [
          Row(children: [
            Expanded(flex: 5, child: NumberField(
              label: tr(widget.store, 'Deposit', 'Inleg', 'Anapara'),
              controller: principal, onChanged: changed, suffix: symbol)),
            const SizedBox(width: 12),
            Expanded(flex: 3, child: KSelect<String>(
              label:'Currency', value: currency,
              options:const [KSelectOption('TRY','TRY'), KSelectOption('EUR','EUR'), KSelectOption('USD','USD')],
              onChanged:(v){currency=v;changed();})),
          ]),
          const SizedBox(height: 21),
          Row(children: [
            Expanded(child: NumberField(label: 'Annual rate', controller: rate,
              onChanged: changed, suffix: '%')),
            const SizedBox(width: 12),
            Expanded(child: NumberField(label: 'Stopaj', controller: stopaj,
              onChanged: changed, suffix: '%')),
          ]),
          const SizedBox(height: 21),
          Row(children: [
            Expanded(child: NumberField(label: 'Term', controller: days,
              onChanged: changed, suffix: 'days', integer: true)),
            const SizedBox(width: 12),
            Expanded(child: NumberField(label: 'Periods', controller: periods,
              onChanged: changed, integer: true)),
          ]),
          const SizedBox(height: 21),
          _optionRow('Reinvest interest', reinvest, (value) {reinvest=value;changed();}),
        ])),
        const SizedBox(height: 6),
        ExpansionTile(
          tilePadding: EdgeInsets.zero, childrenPadding: const EdgeInsets.only(bottom: 8),
          title: Text(tr(widget.store,'Calculation options','Berekeningsopties','Hesap ayarları'),
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          leading: const Icon(Icons.tune_outlined, size: 19),
          initiallyExpanded: showOptions,
          onExpansionChanged: (v) => showOptions = v,
          children: [
            NumberField(label: 'Annual day-count basis',controller: basis,
              onChanged: changed, suffix: 'days',integer: true),
            const SizedBox(height: 6),
            _optionRow('Calendar months',calendar,(v){calendar=v;changed();}),
            if (calendar) TextButton.icon(onPressed: () async {
              final date = await showDatePicker(context: context, initialDate: from,
                firstDate: DateTime(2000),lastDate: DateTime(2100));
              if (date != null) {from=date;changed();}
            }, icon: const Icon(Icons.calendar_month_outlined),
              label: Text('Start · ${from.year}-${from.month.toString().padLeft(2,'0')}')),
          ]),
        if (r != null) ...[
          const SectionHead('Growth'),
          ChartLine(values: [Dec.parse(principal.text).toDouble(),
            ...r.rows.map((e) =>
              (reinvest ? e.ending : e.starting + e.accumulated).toDouble())],
            height: 184),
          const SizedBox(height: 11),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Starting', style: TextStyle(fontSize: 12,color:muted(context))),
            Text('Projected', style: TextStyle(fontSize: 12,color:muted(context))),
          ]),
          const SectionHead('Periods'),
          for (final e in r.rows) ...[
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(bottom: 13),
              shape: const Border(), collapsedShape: const Border(),
              title: Text('Period ${e.period}',style: const TextStyle(
                fontWeight: FontWeight.w600,fontSize: 15)),
              subtitle: Text('${e.days} days · +${fmt(e.net)}',
                style: TextStyle(fontSize: 12, color: muted(context))),
              trailing: SizedBox(width: 145,child: Row(
                mainAxisAlignment: MainAxisAlignment.end,children:[
                  Flexible(child: FittedBox(fit: BoxFit.scaleDown, child:
                    Text(fmt(e.ending), maxLines: 1,
                      style: const TextStyle(fontSize: 14.5,fontWeight: FontWeight.w600)))),
                  const SizedBox(width: 4),
                  const Icon(Icons.expand_more,size: 18),
                ])),
              children: [
                _line('Starting',fmt(e.starting)),
                _line('Gross',fmt(e.gross)),
                _line('Tax',fmt(e.tax)),
                _line('Net',fmt(e.net)),
                _line('Cumulative',fmt(e.accumulated)),
              ]),
            Divider(height: 1,color:Theme.of(context).dividerColor),
          ],
          const SizedBox(height: 25),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => export(false,r),
              icon: const Icon(Icons.file_download_outlined,size: 18),
              label: const Text('CSV'))),
            const SizedBox(width: 12),
            Expanded(child: FilledButton.icon(
              onPressed: () => export(true,r),
              icon: const Icon(Icons.ios_share_outlined,size: 18),
              label: const Text('Share PDF'))),
          ]),
          const SizedBox(height: 10),
          TextButton.icon(onPressed: saveScenario,
            icon: const Icon(Icons.bookmark_add_outlined,size: 19),
            label: const Text('Save this scenario')),
        ],
        const SizedBox(height: 20),
        const Hint('Estimates only. Stopaj rates vary by account and term. Additional Dutch tax may apply.'),
      ]);
  }

  Widget _optionRow(String label, bool value, ValueChanged<bool> onChanged) =>
    SwitchListTile(
      dense: true, contentPadding: EdgeInsets.zero, title: Text(label,
        style: const TextStyle(fontSize: 14.5,fontWeight: FontWeight.w600)),
      value: value, onChanged: onChanged);
  Widget _line(String title, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [Expanded(child: Text(title)), Text(value, style: const TextStyle(fontWeight: FontWeight.w700))]));
  Future<void> export(bool pdf, InterestResult r) async {
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final table = [<String>['Period','Days','Starting','Gross','Tax','Net','Ending'],
      ...r.rows.map((e) => [e.period.toString(), e.days.toString(), e.starting.toFixed(2),
        e.gross.toFixed(2), e.tax.toFixed(2), e.net.toFixed(2), e.ending.toFixed(2)])];
    try {
      if (pdf) {
        await Reports.savePdf('kalqo_faiz_$stamp.pdf', [
          'KALQO / FAIZ REPORT', 'Currency: $currency',
          'Principal: ${principal.text}', 'Interest rate: ${rate.text}% annual',
          'Term days: ${days.text}; periods: ${periods.text}',
          'Withholding tax: ${stopaj.text}%', 'Gross total: ${r.totalGross.toFixed(2)}',
          'Tax total: ${r.totalTax.toFixed(2)}', 'Net earned: ${r.totalNet.toFixed(2)}',
          'Ending principal: ${r.closingBalance.toFixed(2)}', '',
          ...table.map((row) => row.join(' | ')), '',
          'Estimates only; cross-border tax obligations excluded.'], widget.store);
      } else {
        await Reports.saveCsv('kalqo_faiz_$stamp.csv', table, widget.store);
      }
      if (mounted) notice(context, 'Report saved / share options opened');
    } catch (e) {if (mounted) notice(context, 'Export failed: $e');}
  }
  Future<void> saveScenario() async {
    final name = await askName(context, 'Save interest scenario');
    if (name != null) {widget.store.addScenario('faiz', name, snapshot()); if (mounted) notice(context, 'Scenario saved');}
  }
  void scenarios() {
    final entries = widget.store.scenarios.where((s) => s['kind'] == 'faiz').toList();
    showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (ctx) => SafeArea(
      child: ListView(shrinkWrap: true, children: [const ListTile(title: Text('Saved interest scenarios',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
        if (entries.isEmpty) const ListTile(title: Text('No saved scenarios')),
        ...entries.map((s) => ListTile(title: Text('${s['name']}'), subtitle: Text('${s['saved']}'.split('T').first),
          onTap: () {restore(Map<String, dynamic>.from(s['data'] as Map)); changed(); Navigator.pop(ctx);},
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () {
            widget.store.removeScenario('${s['id']}'); Navigator.pop(ctx); scenarios();})))])));
  }
}
