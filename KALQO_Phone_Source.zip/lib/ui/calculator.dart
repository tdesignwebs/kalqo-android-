import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/calc.dart';
import '../core/storage.dart';
import 'common.dart';

class CalculatorPage extends StatefulWidget {
  final AppStore store;
  const CalculatorPage({super.key, required this.store});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}
class _CalculatorPageState extends State<CalculatorPage> {
  String expression = '0';
  String preview = '';
  final engine = ExpressionCalculator();
  void tap(String value) {
    HapticFeedback.selectionClick();
    setState(() {
      if (value == 'AC') {
        expression = '0'; preview = ''; return;
      }
      if (value == '⌫') {
        expression = expression.length > 1 ? expression.substring(0, expression.length - 1) : '0';
      } else if (value == '+/-') {
        final wrapped = RegExp(r'\(-([0-9]+(?:\.[0-9]+)?)\)$').firstMatch(expression);
        if (wrapped != null) {
          expression = expression.substring(0, wrapped.start) + wrapped.group(1)!;
        } else {
          final last = RegExp(r'([0-9]+(?:\.[0-9]+)?)$').firstMatch(expression);
          if (last != null) {
            final number = last.group(1)!;
            final unaryNegative = last.start > 0 && expression[last.start - 1] == '-' &&
              (last.start == 1 || '+×÷(−'.contains(expression[last.start - 2]));
            if (unaryNegative) {
              expression = expression.substring(0, last.start - 1) + number;
            } else {
              expression = expression.substring(0, last.start) + '(-$number)';
            }
          }
        }
      } else if (value == '=') {
        try {
          final result = engine.evaluate(expression).toFixed(9);
          final trimmed = result.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
          widget.store.addHistory(expression, trimmed);
          expression = trimmed;
          preview = '';
        } catch (e) { preview = e is StateError ? 'Cannot divide by zero' : 'Invalid expression'; }
      } else {
        if (value == '.') {
          final current = RegExp(r'(\d*\.?\d*)$').firstMatch(expression)?.group(0) ?? '';
          if (current.contains('.')) return;
          if (current.isEmpty) value = '0.';
        }
        if ('+−×÷'.contains(value) && value.length == 1 && '+−×÷'.contains(expression[expression.length - 1])) {
          expression = expression.substring(0, expression.length - 1) + value;
        } else {
          expression = expression == '0' && !'+−×÷.%'.contains(value) ? value : expression + value;
        }
      }
      if (value != '=') {
        try {preview = engine.evaluate(expression).toFixed(2);} catch (_) {preview = '';}
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final keys = ['AC', '+/-', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−',
      '1', '2', '3', '+', '⌫', '0', '.', '='];
    return LayoutBuilder(builder: (context, bounds) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      child: Column(children: [
        Expanded(flex: 3, child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.end,
          children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(tr(widget.store, 'Everyday calculations', 'Dagelijks rekenen', 'Günlük hesaplama'),
              style: TextStyle(fontSize: 13, color: Theme.of(context).hintColor)),
            IconButton(tooltip: 'History', icon: const Icon(Icons.history_rounded), onPressed: historySheet)]),
            const Spacer(),
            SingleChildScrollView(scrollDirection: Axis.horizontal, reverse: true,
              child: Text(expression, maxLines: 1, textAlign: TextAlign.end,
                style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w700, letterSpacing: -1.6))),
            const SizedBox(height: 12),
            Text(preview.isEmpty ? ' ' : '= $preview',
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700, color: accent)),
            const SizedBox(height: 13),
          ])),
        Flexible(flex: 7, child: LayoutBuilder(builder: (_, b) {
          final keyHeight = (b.maxHeight - 36) / 5;
          return GridView.builder(physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4,
              mainAxisSpacing: 9, crossAxisSpacing: 9, mainAxisExtent: keyHeight),
            itemCount: keys.length, itemBuilder: (context, i) {
              final k = keys[i];
              final isEquals = k == '=';
              final isOperator = ['÷', '×', '−', '+'].contains(k);
              return Material(color: isEquals ? accent :
                (dark ? (isOperator ? const Color(0xFF27384D) : const Color(0xFF22262D)) :
                  (isOperator ? const Color(0xFFE8F0FF) : Colors.white)),
                borderRadius: BorderRadius.circular(17),
                child: InkWell(borderRadius: BorderRadius.circular(17), onTap: () => tap(k),
                  child: Center(child: Text(k, style: TextStyle(fontSize: k.length > 1 ? 17 : 26,
                    fontWeight: FontWeight.w700, color: isEquals ? Colors.white : isOperator ? accent : null)))));
            });
        })),
      ])));
  }
  void historySheet() {
    showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true,
      builder: (ctx) => SafeArea(child: SizedBox(height: MediaQuery.sizeOf(ctx).height * .58,
        child: Column(children: [Padding(padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Row(children: [const Expanded(child: Text('History', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            TextButton(onPressed: () {widget.store.clearHistory(); Navigator.pop(ctx);}, child: const Text('Clear all'))])),
          Expanded(child: widget.store.history.isEmpty ? const Center(child: Text('No calculations yet')) :
            ListView.builder(itemCount: widget.store.history.length, itemBuilder: (context, i) {
              final h = widget.store.history[i];
              return ListTile(title: Text('${h['expression']}'), subtitle: Text('= ${h['answer']}', style: const TextStyle(color: accent, fontWeight: FontWeight.w700)),
                onTap: () {setState(() {expression = '${h['answer']}'; preview = '';}); Navigator.pop(ctx);},
                trailing: IconButton(icon: const Icon(Icons.copy_outlined), onPressed: () {
                  Clipboard.setData(ClipboardData(text: '${h['answer']}')); notice(ctx, 'Copied');}));
            })),
        ]))));
  }
}
