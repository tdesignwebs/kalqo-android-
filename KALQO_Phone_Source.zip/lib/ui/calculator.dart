import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/calc.dart';
import '../core/storage.dart';
import 'common.dart';

class CalculatorPage extends StatefulWidget {
  final AppStore store;
  const CalculatorPage({super.key, required this.store});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}
class _CalculatorPageState extends State<CalculatorPage> {
  String expression = '0';
  String preview = '';
  final engine = ExpressionCalculator();
  void tap(String value) {
    HapticFeedback.selectionClick();
    setState(() {
      if (value == 'AC') {
        expression = '0'; preview = ''; return;
      }
      if (value == '⌫') {
        expression = expression.length > 1 ? expression.substring(0, expression.length - 1) : '0';
      } else if (value == '+/-') {
        final wrapped = RegExp(r'\(-([0-9]+(?:\.[0-9]+)?)\)$').firstMatch(expression);
        if (wrapped != null) {
          expression = expression.substring(0, wrapped.start) + wrapped.group(1)!;
        } else {
          final last = RegExp(r'([0-9]+(?:\.[0-9]+)?)$').firstMatch(expression);
          if (last != null) {
            final number = last.group(1)!;
            final unaryNegative = last.start > 0 && expression[last.start - 1] == '-' &&
              (last.start == 1 || '+×÷(−'.contains(expression[last.start - 2]));
            if (unaryNegative) {
              expression = expression.substring(0, last.start - 1) + number;
            } else {
              expression = expression.substring(0, last.start) + '(-$number)';
            }
          }
        }
      } else if (value == '=') {
        try {
          final result = engine.evaluate(expression).toFixed(9);
          final trimmed = result.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
          widget.store.addHistory(expression, trimmed);
          expression = trimmed;
          preview = '';
        } catch (e) { preview = e is StateError ? 'Cannot divide by zero' : 'Invalid expression'; }
      } else {
        if (value == '.') {
          final current = RegExp(r'(\d*\.?\d*)$').firstMatch(expression)?.group(0) ?? '';
          if (current.contains('.')) return;
          if (current.isEmpty) value = '0.';
        }
        if ('+−×÷'.contains(value) && value.length == 1 && '+−×÷'.contains(expression[expression.length - 1])) {
          expression = expression.substring(0, expression.length - 1) + value;
        } else {
          expression = expression == '0' && !'+−×÷.%'.contains(value) ? value : expression + value;
        }
      }
      if (value != '=') {
        try {preview = engine.evaluate(expression).toFixed(2);} catch (_) {preview = '';}
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final keys = ['AC', '+/-', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−',
      '1', '2', '3', '+', '⌫', '0', '.', '='];
    return Padding(
      padding: const EdgeInsets.fromLTRB(19, 10, 19, 12),
      child: Column(children:[
        Expanded(flex: 28,child:Column(
          crossAxisAlignment:CrossAxisAlignment.end,
          children:[
            Row(children:[
              Text(tr(widget.store,'Calculator','Rekenmachine','Hesap Makinesi'),
                style:TextStyle(fontSize:15,color:muted(context))),
              const Spacer(),
              IconButton(onPressed:historySheet,tooltip:'History',
                icon:const Icon(Icons.history_rounded,size:23)),
            ]),
            const Spacer(),
            SingleChildScrollView(
              scrollDirection:Axis.horizontal,reverse:true,
              child:Text(expression,maxLines:1,textAlign:TextAlign.end,
                style:const TextStyle(fontSize:55,letterSpacing:-2.4,
                  fontWeight:FontWeight.w600))),
            const SizedBox(height:12),
            Text(preview.isEmpty?' ': '= $preview',
              style:TextStyle(fontSize:20,color:preview.isEmpty?muted(context):accent,
                fontWeight:FontWeight.w600)),
            const SizedBox(height:20),
          ])),
        Expanded(flex:72,child:LayoutBuilder(builder:(context,bounds){
          final keyHeight=(bounds.maxHeight-38)/5;
          return GridView.builder(
            physics:const NeverScrollableScrollPhysics(),
            gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:4,mainAxisExtent:keyHeight,
              mainAxisSpacing:9,crossAxisSpacing:9),
            itemCount:keys.length,itemBuilder:(context,i){
              final k=keys[i];
              final eq=k=='=';
              final op=['÷','×','−','+'].contains(k);
              final function=['AC','+/-','%','⌫'].contains(k);
              final bg=eq?accent:op?(dark?const Color(0xFF223248):const Color(0xFFE6EFFF))
                :function?(dark?const Color(0xFF20252E):const Color(0xFFECEFF3))
                :Colors.transparent;
              return Material(color:bg,borderRadius:BorderRadius.circular(18),
                child:InkWell(
                  borderRadius:BorderRadius.circular(18),onTap:()=>tap(k),
                  child:Center(child:Text(k,style:TextStyle(
                    color:eq?Colors.white:op?accent:null,
                    fontWeight:eq?FontWeight.w700:FontWeight.w500,
                    fontSize:k.length>1?18:27)))));
            });
        })),
      ]));
  }
  void historySheet() {
    showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true,
      builder: (ctx) => SafeArea(child: SizedBox(height: MediaQuery.sizeOf(ctx).height * .58,
        child: Column(children: [Padding(padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Row(children: [const Expanded(child: Text('History', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
            TextButton(onPressed: () {widget.store.clearHistory(); Navigator.pop(ctx);}, child: const Text('Clear all'))])),
          Expanded(child: widget.store.history.isEmpty ? const Center(child: Text('No calculations yet')) :
            ListView.builder(itemCount: widget.store.history.length, itemBuilder: (context, i) {
              final h = widget.store.history[i];
              return ListTile(title: Text('${h['expression']}'), subtitle: Text('= ${h['answer']}', style: const TextStyle(color: accent, fontWeight: FontWeight.w700)),
                onTap: () {setState(() {expression = '${h['answer']}'; preview = '';}); Navigator.pop(ctx);},
                trailing: IconButton(icon: const Icon(Icons.copy_outlined), onPressed: () {
                  Clipboard.setData(ClipboardData(text: '${h['answer']}')); notice(ctx, 'Copied');}));
            })),
        ]))));
  }
}
