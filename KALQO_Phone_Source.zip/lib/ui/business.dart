import 'package:flutter/material.dart';
import '../core/decimal.dart';
import '../core/finance.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class BusinessPage extends StatefulWidget {
  final AppStore store;
  const BusinessPage({super.key, required this.store});
  @override
  State<BusinessPage> createState() => _BusinessPageState();
}
class _BusinessPageState extends State<BusinessPage> {
  final Map<String, TextEditingController> f = {};
  final Map<String, String> defaults = {
    'clients': '100', 'basic': '39', 'medium': '59', 'pro': '79',
    'basicClients': '0', 'mediumClients': '100', 'proClients': '0',
    'vat': '21', 'providerPercent': '0', 'providerFixed': '0', 'transactions': '0',
    'taxEffective': '30', 'otherIncome': '0', 'credits': '0', 'deductions': '0',
    'salary': '0', 'dividends': '0', 'growthNew': '10', 'growthChurn': '2',
    'growthCost': '0', 'compareClients': '500',
  };
  bool advanced = false, vatIncluded = false, entrepreneur = false, hours = false,
    starter = false, mkb = false, zvw = false, showGrowth = false;
  String selectedPlan = 'medium';
  TaxMode taxMode = TaxMode.simple;
  int taxYear = 2026;
  bool restored = false;
  late List<BusinessExpense> expenses;
  @override
  void initState() {
    super.initState();
    defaults['basic'] = widget.store.preferences['basicPrice'] ?? '39';
    defaults['medium'] = widget.store.preferences['mediumPrice'] ?? '59';
    defaults['pro'] = widget.store.preferences['proPrice'] ?? '79';
    defaults['vat'] = widget.store.preferences['vatRate'] ?? '21';
    for (final e in defaults.entries) f[e.key] = TextEditingController(text: e.value);
    expenses = [
      BusinessExpense(id: 'supabase', name: 'Supabase', amount: Dec.fromInt(20)),
      BusinessExpense(id: 'domain', name: 'Domain / Hosting', amount: Dec.fromInt(10), frequency: ExpenseFrequency.yearly),
    ];
  }
  int n(String key) => int.tryParse(f[key]!.text) ?? 0;
  Dec v(String key) => Dec.parse(f[key]!.text);
  List<int> get clientCounts => advanced ? [n('basicClients'),n('mediumClients'),n('proClients')] :
    [selectedPlan == 'basic' ? n('clients') : 0,
      selectedPlan == 'medium' ? n('clients') : 0,
      selectedPlan == 'pro' ? n('clients') : 0];
  BusinessResult? get calculation {
    try {
      return calculateBusiness(BusinessInput(clients: clientCounts,
        prices: [v('basic'),v('medium'),v('pro')], expenses: expenses,
        vatRate: v('vat'), providerPercent: v('providerPercent'),
        providerFixed: v('providerFixed'), monthlyTransactions: n('transactions'),
        pricesIncludeVat: vatIncluded));
    } catch (_) {return null;}
  }
  TaxInput? get taxes {
    try {
      return TaxInput(mode: taxMode, year: taxYear, effectivePercent: v('taxEffective'),
        otherIncome: v('otherIncome'), manualCredits: v('credits'), otherDeduction: v('deductions'),
        salaryCost: v('salary'), expectedDividends: v('dividends'),
        qualifyingEntrepreneur: entrepreneur, meetsHours: hours,
        starter: starter, applyMkb: mkb, includeZvw: zvw);
    } catch (_) {return null;}
  }
  TaxResult? get taxResult {
    final c = calculation, t = taxes;
    return c != null && t != null ? estimateTax(c.annualProfit, t) : null;
  }
  Map<String, dynamic> snapshot() => {
    'fields': f.map((key, value) => MapEntry(key,value.text)),
    'advanced': advanced, 'vatIncluded': vatIncluded, 'plan': selectedPlan,
    'taxMode': taxMode.name, 'taxYear': taxYear, 'entrepreneur': entrepreneur,
    'hours': hours, 'starter': starter, 'mkb': mkb, 'zvw': zvw,
    'expenses': expenses.map((x) => x.toJson()).toList(),
  };
  void restore(Map<String, dynamic> m) {
    final fields = m['fields'];
    if (fields is Map) {
      for (final entry in fields.entries) {
        if (f.containsKey('${entry.key}')) f['${entry.key}']!.text = '${entry.value}';
      }
    }
    advanced = m['advanced'] == true;
    vatIncluded = m['vatIncluded'] == true;
    selectedPlan = '${m['plan'] ?? 'medium'}';
    taxMode = TaxMode.values.firstWhere((e) => e.name == m['taxMode'], orElse: () => TaxMode.simple);
    taxYear = (m['taxYear'] as num?)?.toInt() ?? 2026;
    entrepreneur = m['entrepreneur'] == true; hours = m['hours'] == true;
    starter = m['starter'] == true; mkb = m['mkb'] == true; zvw = m['zvw'] == true;
    if (m['expenses'] is List) {
      expenses = (m['expenses'] as List).map((item) => BusinessExpense.fromJson(Map<String,dynamic>.from(item as Map))).toList();
    }
  }
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      restored = true;
      final draft = widget.store.drafts['business'];
      if (draft is Map) restore(Map<String, dynamic>.from(draft));
    }
  }
  void changed() {widget.store.setDraft('business', snapshot()); setState(() {});}
  @override
  void dispose() {for (final x in f.values) x.dispose(); super.dispose();}
  Widget field(String key, String title, {String? suffix, bool integer = false}) =>
    NumberField(label: title, controller: f[key]!, onChanged: changed, suffix: suffix, integer: integer);
  Widget gap() => const SizedBox(height: 10);
  String euros(Dec amount) => money(amount, widget.store);

  @override
  Widget build(BuildContext context) {
    final r = calculation, tax = taxResult;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
      const SizedBox(height: 10),
      const Text('AXREON', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 30, letterSpacing: -.9)),
      Hint(tr(widget.store, 'Your SaaS revenue & profit studio', 'Jouw SaaS omzet- en winstcalculator',
        'SaaS gelir ve kâr hesaplayıcı')),
      const SectionHead('Subscription simulator'),
      KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SwitchListTile(contentPadding: EdgeInsets.zero, value: advanced,
          title: const Text('Advanced plan mix', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('Set clients separately for each plan'),
          onChanged: (val) {advanced = val; changed();}),
        if (!advanced) ...[
          field('clients', 'Total paying clients', integer: true), gap(),
          DropdownButtonFormField<String>(key: ValueKey(selectedPlan), initialValue: selectedPlan,
            decoration: const InputDecoration(labelText: 'Subscription plan'),
            items: const [DropdownMenuItem(value:'basic',child:Text('Basic')),
              DropdownMenuItem(value:'medium',child:Text('Medium')),
              DropdownMenuItem(value:'pro',child:Text('Pro'))],
            onChanged: (x) {if (x != null) {selectedPlan = x; changed();}}), gap(),
        ] else ...[
          field('basicClients', 'Basic clients', integer: true), gap(),
          field('mediumClients', 'Medium clients', integer: true), gap(),
          field('proClients', 'Pro clients', integer: true), gap(),
        ],
        Row(children: [Expanded(child: field('basic', 'Basic price', suffix:'€')),
          const SizedBox(width:8), Expanded(child: field('medium', 'Medium price', suffix:'€')),
          const SizedBox(width:8), Expanded(child: field('pro', 'Pro price', suffix:'€'))]),
        gap(),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Prices include VAT'),
          subtitle: const Text('Off: subscription prices exclude VAT'), value: vatIncluded,
          onChanged: (x) {vatIncluded = x; changed();}),
        field('vat', 'Dutch VAT rate', suffix: '%'),
      ])),
      const SectionHead('Monthly overview'),
      if (r == null) const KCard(child: Text('Enter valid non-negative financial values.'))
      else ...[
        MetricGrid(children: [
          Metric(label:'Paying clients',value:'${r.totalClients}',icon:Icons.groups_outlined),
          Metric(label:'Monthly revenue · ex VAT',value:euros(r.monthlyRevenue),highlighted:true,icon:Icons.trending_up),
          Metric(label:'Annual revenue · ex VAT',value:euros(r.monthlyRevenue * Dec.fromInt(12))),
          Metric(label:'Monthly expenses · ex VAT',value:euros(r.monthlyExpenses),icon:Icons.payments_outlined),
          Metric(label:'Monthly operating profit',value:euros(r.operatingProfit),highlighted:true),
          Metric(label:'Annual operating profit',value:euros(r.annualProfit)),
        ]),
        const SectionHead('VAT flow'),
        KCard(child: Column(children: [
          _pair('Invoice amount · including VAT',euros(r.invoiced)),
          _pair('Output VAT charged',euros(r.outputVat)),
          _pair('Recoverable input VAT estimate',euros(r.inputVat)),
          const Divider(height: 22),
          _pair('Estimated VAT payable',euros(r.netVat),emphasis:true),
          const Hint('VAT is separate from business profit. Actual VAT depends on customer location, tax treatment and eligible input VAT.'),
        ])),
      ],
      const SectionHead('Running expenses', action: SizedBox.shrink()),
      KCard(child: Column(children: [
        ...expenses.map((expense) => Column(children: [
          ListTile(contentPadding: EdgeInsets.zero, onTap: () => editExpense(expense),
            title: Text(expense.name,style: TextStyle(fontWeight: FontWeight.w700,
              decoration: expense.enabled ? null : TextDecoration.lineThrough)),
            subtitle: Text('${expense.frequency.name} · ${expense.vatTreatment.name} VAT'),
            trailing: Text(euros(expense.monthlyAmount()),style: const TextStyle(fontWeight: FontWeight.w800))),
          const Divider(height: 1),
        ])),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => editExpense(null), icon: const Icon(Icons.add),
          label: const Text('Add or edit an expense')),
        const Hint('One-time expenses are tracked separately and excluded from recurring monthly profits.'),
      ])),
      const SectionHead('Payment processing'),
      KCard(child: Column(children: [
        field('providerPercent', 'Provider fee per transaction', suffix: '%'), gap(),
        field('providerFixed', 'Fixed fee per transaction', suffix:'€'), gap(),
        field('transactions', 'Transactions per month',integer:true),
        if (r != null) ...[gap(), _pair('Estimated monthly fees',euros(r.processingFees))],
      ])),
      const SectionHead('Dutch tax estimator'),
      KCard(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        DropdownButtonFormField<TaxMode>(key:ValueKey(taxMode),initialValue:taxMode,
          decoration:const InputDecoration(labelText:'Tax / business structure'),
          items: const [DropdownMenuItem(value:TaxMode.simple,child:Text('Simple effective tax reserve')),
            DropdownMenuItem(value:TaxMode.soleTrader,child:Text('Eenmanszaak · Box 1')),
            DropdownMenuItem(value:TaxMode.bv,child:Text('BV · Corporate tax'))],
          onChanged:(value){if(value!=null){taxMode=value;changed();}}), gap(),
        DropdownButtonFormField<int>(key:ValueKey(taxYear),initialValue:taxYear,
          decoration:const InputDecoration(labelText:'Tax year'),
          items:const [DropdownMenuItem(value:2026,child:Text('2026 · official rates')),
            DropdownMenuItem(value:2027,child:Text('2027 · rates not configured'))],
          onChanged:(value){if(value!=null){taxYear=value;changed();}}),gap(),
        if (taxMode == TaxMode.simple) ...[
          field('taxEffective', 'Effective income tax reserve',suffix:'%'),
          const Hint('This is a planning percentage, not official tax due.'),
        ],
        if(taxMode == TaxMode.soleTrader)...[
          field('otherIncome','Other annual taxable income',suffix:'€'),gap(),
          field('deductions','Other eligible annual deductions',suffix:'€'),gap(),
          field('credits','Manual tax credit allocation',suffix:'€'),gap(),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:entrepreneur,title:const Text('Eligible entrepreneur'),
            onChanged:(x){entrepreneur=x;changed();}),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:hours,title:const Text('Meets hours criterion'),
            onChanged:(x){hours=x;changed();}),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:starter,title:const Text('Eligible startersaftrek'),
            onChanged:(x){starter=x;changed();}),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:mkb,title:const Text('Eligible MKB-winstvrijstelling'),
            onChanged:(x){mkb=x;changed();}),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:zvw,title:const Text('Include estimated Zvw contribution'),
            onChanged:(x){zvw=x;changed();}),
          const Hint('2026: Box 1 progressive 35.75% / 37.56% / 49.50%. Entrepreneur deductions require eligibility; deduction caps and credits need professional review.'),
        ],
        if(taxMode == TaxMode.bv)...[
          field('salary','Annual gross director salary (company expense)',suffix:'€'),gap(),
          field('dividends','Planned dividends (informational only)',suffix:'€'),
          const Hint('2026 corporate tax: 19% through €200,000, then 25.8%. Personal director salary and dividend taxes are NOT included.'),
        ],
      ])),
      if(tax != null && r != null)...[
        const SectionHead('After-tax projection'),
        MetricGrid(children:[
          Metric(label: taxMode == TaxMode.bv ? 'Estimated corporate tax / year' : 'Tax reserve / year',
            value:tax.estimated ? euros(tax.yearlyBusinessTax) : 'N/A'),
          Metric(label:'Tax reserve / month',value:tax.estimated ? euros(tax.yearlyBusinessTax / Dec.fromInt(12)) : 'N/A'),
          Metric(label:taxMode == TaxMode.bv ? 'Remaining in BV · month' : 'Net profit / month',
            value:tax.estimated ? euros(tax.yearlyAfterTax / Dec.fromInt(12)) : 'N/A',highlighted:true),
          Metric(label:taxMode == TaxMode.bv ? 'Remaining in BV · year' : 'Net profit / year',
            value:tax.estimated ? euros(tax.yearlyAfterTax) : 'N/A',highlighted:true),
          Metric(label:'Operating profit margin',value:'${r.monthlyRevenue > Dec.zero ? ((r.operatingProfit / r.monthlyRevenue)*Dec.fromInt(100)).toFixed(1) : '0'}%'),
          Metric(label:'Annual tax basis',value:euros(tax.taxableBase)),
        ]),
        Hint(tax.explanation),
      ],
      const SectionHead('12-month growth simulator'),
      KCard(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        SwitchListTile(contentPadding:EdgeInsets.zero,value:showGrowth,
          title:const Text('Show business growth projections',style:TextStyle(fontWeight:FontWeight.w700)),
          onChanged:(x){showGrowth=x;setState((){});}),
        if(showGrowth)...[
          field('growthNew','New customers per month',integer:true),gap(),
          field('growthChurn','Monthly churn',suffix:'%'),gap(),
          field('growthCost','Monthly expense growth',suffix:'%'),gap(),
          if(r != null) _buildGrowth(r),
        ],
      ])),
      const SectionHead('Compare client scenarios'),
      KCard(child: Column(children:[field('compareClients','Comparison client count',integer:true),
        if(r != null)...[gap(), _compare(r)]])),
      const SizedBox(height:15),
      Row(children:[Expanded(child:OutlinedButton.icon(onPressed: r == null || tax == null || !tax.estimated ? null : () => export(false, r,tax),
        icon:const Icon(Icons.table_rows_outlined),label:const Text('Export CSV'))),
        const SizedBox(width:10),
        Expanded(child:FilledButton.icon(onPressed: r == null || tax == null || !tax.estimated ? null : () => export(true,r,tax),
          icon:const Icon(Icons.picture_as_pdf_outlined),label:const Text('Share PDF')))]),
      gap(),
      OutlinedButton.icon(onPressed:saveScenario,icon:const Icon(Icons.bookmark_add_outlined),label:const Text('Save scenario')),
      gap(),
      OutlinedButton.icon(onPressed:scenarios,icon:const Icon(Icons.folder_open_outlined),label:const Text('Saved scenarios')),
      const SizedBox(height:12),
      const Hint('Planning tool, not tax or accounting advice. Excludes non-entered costs, owner-specific deductions, and tax rules that require individualized assessment.'),
    ]);
  }

  Widget _pair(String label,String value,{bool emphasis=false}) =>
    Padding(padding: const EdgeInsets.symmetric(vertical:7),child:Row(children:[
      Expanded(child:Text(label,style:TextStyle(fontSize:12.5,color:Theme.of(context).hintColor))),
      Text(value,style:TextStyle(fontWeight:FontWeight.w800,color:emphasis?accent:null))]));

  Widget _compare(BusinessResult original) {
    try {
      final count = n('compareClients');
      if (count < 0) return const Text('Enter a valid number of clients');
      final cmp = calculateBusiness(BusinessInput(clients:[0,count,0],
        prices:[v('basic'),v('medium'),v('pro')], expenses:expenses,
        vatRate:v('vat'),providerPercent:v('providerPercent'),providerFixed:v('providerFixed'),
        monthlyTransactions:n('transactions'),pricesIncludeVat:vatIncluded));
      return Column(children:[
        _pair('Your current scenario · monthly revenue',euros(original.monthlyRevenue)),
        _pair('$count Medium clients · monthly revenue',euros(cmp.monthlyRevenue)),
        _pair('Difference · monthly revenue',euros(cmp.monthlyRevenue-original.monthlyRevenue),emphasis:true),
        _pair('Difference · operating profit',euros(cmp.operatingProfit-original.operatingProfit)),
        if (taxes != null && taxYear == 2026) _pair('Difference · after-tax (annual)',
          euros(estimateTax(cmp.annualProfit, taxes!).yearlyAfterTax -
            estimateTax(original.annualProfit, taxes!).yearlyAfterTax)),
        const Hint('Comparison always uses the Medium subscription at its current editable price.'),
      ]);
    } catch (_) {return const Hint('Comparison unavailable until inputs are valid.');}
  }

  Widget _buildGrowth(BusinessResult base) {
    try {
      final avg = base.totalClients > 0 ? base.monthlyRevenue / Dec.fromInt(base.totalClients) : v('medium');
      final rows = simulateGrowth(startClients:base.totalClients,newClients:n('growthNew'),
        churnPercent:v('growthChurn'),price:avg,
        startingExpenses:base.monthlyExpenses,expenseGrowthPercent:v('growthCost'),
        effectiveTaxPercent:v('taxEffective'));
      return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SizedBox(height:14),
        ChartLine(values:rows.map((row)=>row.revenue.toDouble()).toList()),
        const SizedBox(height:10),
        _pair('Month 12 · customers','${rows.last.clients}'),
        _pair('Month 12 · MRR',euros(rows.last.revenue)),
        _pair('Month 12 · ARR run-rate',euros(rows.last.revenue*Dec.fromInt(12))),
        _pair('Cumulative 12-month net',euros(rows.last.cumulative),emphasis:true),
        const SizedBox(height:8),
        ...rows.map((row)=>ExpansionTile(tilePadding:EdgeInsets.zero,
          title:Text('Month ${row.month}  ·  ${row.clients} clients',style:const TextStyle(fontWeight:FontWeight.w700)),
          subtitle:Text(euros(row.revenue)),
          children:[_pair('Revenue',euros(row.revenue)),_pair('Expenses',euros(row.expenses)),
            _pair('Operating profit',euros(row.operating)),
            _pair('Illustrative tax',euros(row.estimatedTax)),
            _pair('Net',euros(row.net)),_pair('Cumulative',euros(row.cumulative))])),
        const Hint('Growth uses a simple monthly effective tax reserve, not final personal tax. Customers are rounded to whole numbers each month.'),
      ]);
    } catch (_) {return const Hint('Enter valid growth inputs.');}
  }

  Future<void> editExpense(BusinessExpense? expense) async {
    final name = TextEditingController(text:expense?.name ?? '');
    final amount = TextEditingController(text:expense?.amount.toFixed(2) ?? '0');
    var frequency = expense?.frequency ?? ExpenseFrequency.monthly;
    var vat = expense?.vatTreatment ?? ExpenseVat.exempt;
    var enabled = expense?.enabled ?? true;
    final outcome = await showDialog<String>(context:context,builder:(dialog) => StatefulBuilder(
      builder:(dialog,setModalState) => AlertDialog(title:Text(expense == null ? 'New expense' : 'Edit expense'),
        content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:name,decoration:const InputDecoration(labelText:'Name')),
          const SizedBox(height:10),
          TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Amount (€)')),
          const SizedBox(height:10),
          DropdownButtonFormField<ExpenseFrequency>(initialValue:frequency,
            decoration:const InputDecoration(labelText:'Frequency'),items:ExpenseFrequency.values.map((e)=>
              DropdownMenuItem(value:e,child:Text(e.name))).toList(),
            onChanged:(x){if(x!=null)setModalState(()=>frequency=x);}),
          const SizedBox(height:10),
          DropdownButtonFormField<ExpenseVat>(initialValue:vat,
            decoration:const InputDecoration(labelText:'VAT treatment'),items:ExpenseVat.values.map((e)=>
              DropdownMenuItem(value:e,child:Text(e.name))).toList(),
            onChanged:(x){if(x!=null)setModalState(()=>vat=x);}),
          SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Active'),value:enabled,
            onChanged:(x)=>setModalState(()=>enabled=x)),
        ])),actions:[
          if(expense!=null)TextButton(onPressed:()=>Navigator.pop(dialog,'delete'),child:const Text('Delete')),
          TextButton(onPressed:()=>Navigator.pop(dialog),child:const Text('Cancel')),
          FilledButton(onPressed:()=>Navigator.pop(dialog,'save'),child:const Text('Save')),
        ])));
    if (outcome == 'delete' && expense!=null) {expenses.removeWhere((e)=>e.id==expense.id);changed();}
    if (outcome == 'save') {
      Dec parsed;
      try {parsed = Dec.parse(amount.text);if(parsed<Dec.zero)throw ArgumentError('Negative');}
      catch (_) {if(mounted)notice(context,'Please enter a valid non-negative amount');name.dispose();amount.dispose();return;}
      if(name.text.trim().isEmpty){if(mounted)notice(context,'Expense name is required');name.dispose();amount.dispose();return;}
      final item=BusinessExpense(id:expense?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name:name.text.trim(),amount:parsed,frequency:frequency,vatTreatment:vat,enabled:enabled);
      if(expense!=null)expenses.removeWhere((e)=>e.id==expense.id);
      expenses.add(item);changed();
    }
    name.dispose();amount.dispose();
  }

  Future<void> export(bool pdf,BusinessResult r,TaxResult t) async {
    final now=DateTime.now().millisecondsSinceEpoch;
    final rows=[['Measure','Monthly','Yearly'],
      ['Clients','${r.totalClients}',''],
      ['Revenue ex VAT',r.monthlyRevenue.toFixed(2),(r.monthlyRevenue*Dec.fromInt(12)).toFixed(2)],
      ['Expenses ex VAT',r.monthlyExpenses.toFixed(2),(r.monthlyExpenses*Dec.fromInt(12)).toFixed(2)],
      ['Operating profit',r.operatingProfit.toFixed(2),r.annualProfit.toFixed(2)],
      ['Estimated tax',(t.yearlyBusinessTax/Dec.fromInt(12)).toFixed(2),t.yearlyBusinessTax.toFixed(2)],
      ['After tax',(t.yearlyAfterTax/Dec.fromInt(12)).toFixed(2),t.yearlyAfterTax.toFixed(2)],
      ['Output VAT',r.outputVat.toFixed(2),(r.outputVat*Dec.fromInt(12)).toFixed(2)],
      ['Input VAT',r.inputVat.toFixed(2),(r.inputVat*Dec.fromInt(12)).toFixed(2)],
      ['VAT due',r.netVat.toFixed(2),(r.netVat*Dec.fromInt(12)).toFixed(2)]];
    try {
      if(pdf) {
        await Reports.savePdf('kalqo_axreon_$now.pdf',[
          'KALQO / AXREON BUSINESS REPORT',
          'Tax mode: ${taxMode.name}; year: $taxYear',
          'VAT rate: ${f['vat']!.text}%',
          ...rows.map((e)=>e.join(' | ')), '', t.explanation,
          'Forecast only; actual taxes and accounting may differ.'],widget.store);
      } else {
        await Reports.saveCsv('kalqo_axreon_$now.csv',rows,widget.store);
      }
      if(mounted)notice(context,'Report saved / share options opened');
    }catch(e){if(mounted)notice(context,'Export failed: $e');}
  }

  Future<void> saveScenario() async {
    final name = await askName(context,'Save AXREON scenario');
    if(name!=null){widget.store.addScenario('business',name,snapshot());if(mounted)notice(context,'Scenario saved');}
  }
  void scenarios(){
    final entries=widget.store.scenarios.where((s)=>s['kind']=='business').toList();
    showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(ctx)=>SafeArea(
      child:ListView(shrinkWrap:true,children:[
        const ListTile(title:Text('Saved AXREON scenarios',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800))),
        if(entries.isEmpty)const ListTile(title:Text('No saved scenarios')),
        ...entries.map((s)=>ListTile(title:Text('${s['name']}'),
          subtitle:Text('${s['saved']}'.split('T').first),
          onTap:(){restore(Map<String,dynamic>.from(s['data'] as Map));changed();Navigator.pop(ctx);},
          trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){
            widget.store.removeScenario('${s['id']}');Navigator.pop(ctx);scenarios();}))),
      ])));
  }
}
