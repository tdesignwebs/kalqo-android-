import 'package:flutter/material.dart';
import '../core/decimal.dart';
import '../core/finance.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class BusinessPage extends StatefulWidget {
  final AppStore store;
  const BusinessPage({super.key, required this.store});
  @override
  State<BusinessPage> createState() => _BusinessPageState();
}
class _BusinessPageState extends State<BusinessPage> {
  final Map<String, TextEditingController> f = {};
  final Map<String, String> defaults = {
    'clients': '100', 'basic': '39', 'medium': '59', 'pro': '79',
    'basicClients': '0', 'mediumClients': '100', 'proClients': '0',
    'vat': '21', 'providerPercent': '0', 'providerFixed': '0', 'transactions': '0',
    'taxEffective': '30', 'otherIncome': '0', 'credits': '0', 'deductions': '0',
    'salary': '0', 'dividends': '0', 'growthNew': '10', 'growthChurn': '2',
    'growthCost': '0', 'compareClients': '500',
  };
  bool advanced = false, vatIncluded = false, entrepreneur = false, hours = false,
    starter = false, mkb = false, zvw = false, showGrowth = false;
  String selectedPlan = 'medium';
  TaxMode taxMode = TaxMode.simple;
  int taxYear = 2026;
  bool restored = false;
  late List<BusinessExpense> expenses;
  @override
  void initState() {
    super.initState();
    defaults['basic'] = widget.store.preferences['basicPrice'] ?? '39';
    defaults['medium'] = widget.store.preferences['mediumPrice'] ?? '59';
    defaults['pro'] = widget.store.preferences['proPrice'] ?? '79';
    defaults['vat'] = widget.store.preferences['vatRate'] ?? '21';
    for (final e in defaults.entries) f[e.key] = TextEditingController(text: e.value);
    expenses = [
      BusinessExpense(id: 'supabase', name: 'Supabase', amount: Dec.fromInt(20)),
      BusinessExpense(id: 'domain', name: 'Domain / Hosting', amount: Dec.fromInt(10), frequency: ExpenseFrequency.yearly),
    ];
  }
  int n(String key) => int.tryParse(f[key]!.text) ?? 0;
  Dec v(String key) => Dec.parse(f[key]!.text);
  List<int> get clientCounts => advanced ? [n('basicClients'),n('mediumClients'),n('proClients')] :
    [selectedPlan == 'basic' ? n('clients') : 0,
      selectedPlan == 'medium' ? n('clients') : 0,
      selectedPlan == 'pro' ? n('clients') : 0];
  BusinessResult? get calculation {
    try {
      return calculateBusiness(BusinessInput(clients: clientCounts,
        prices: [v('basic'),v('medium'),v('pro')], expenses: expenses,
        vatRate: v('vat'), providerPercent: v('providerPercent'),
        providerFixed: v('providerFixed'), monthlyTransactions: n('transactions'),
        pricesIncludeVat: vatIncluded));
    } catch (_) {return null;}
  }
  TaxInput? get taxes {
    try {
      return TaxInput(mode: taxMode, year: taxYear, effectivePercent: v('taxEffective'),
        otherIncome: v('otherIncome'), manualCredits: v('credits'), otherDeduction: v('deductions'),
        salaryCost: v('salary'), expectedDividends: v('dividends'),
        qualifyingEntrepreneur: entrepreneur, meetsHours: hours,
        starter: starter, applyMkb: mkb, includeZvw: zvw);
    } catch (_) {return null;}
  }
  TaxResult? get taxResult {
    final c = calculation, t = taxes;
    return c != null && t != null ? estimateTax(c.annualProfit, t) : null;
  }
  Map<String, dynamic> snapshot() => {
    'fields': f.map((key, value) => MapEntry(key,value.text)),
    'advanced': advanced, 'vatIncluded': vatIncluded, 'plan': selectedPlan,
    'taxMode': taxMode.name, 'taxYear': taxYear, 'entrepreneur': entrepreneur,
    'hours': hours, 'starter': starter, 'mkb': mkb, 'zvw': zvw,
    'expenses': expenses.map((x) => x.toJson()).toList(),
  };
  void restore(Map<String, dynamic> m) {
    final fields = m['fields'];
    if (fields is Map) {
      for (final entry in fields.entries) {
        if (f.containsKey('${entry.key}')) f['${entry.key}']!.text = '${entry.value}';
      }
    }
    advanced = m['advanced'] == true;
    vatIncluded = m['vatIncluded'] == true;
    selectedPlan = '${m['plan'] ?? 'medium'}';
    taxMode = TaxMode.values.firstWhere((e) => e.name == m['taxMode'], orElse: () => TaxMode.simple);
    taxYear = (m['taxYear'] as num?)?.toInt() ?? 2026;
    entrepreneur = m['entrepreneur'] == true; hours = m['hours'] == true;
    starter = m['starter'] == true; mkb = m['mkb'] == true; zvw = m['zvw'] == true;
    if (m['expenses'] is List) {
      expenses = (m['expenses'] as List).map((item) => BusinessExpense.fromJson(Map<String,dynamic>.from(item as Map))).toList();
    }
  }
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!restored) {
      restored = true;
      final draft = widget.store.drafts['business'];
      if (draft is Map) restore(Map<String, dynamic>.from(draft));
    }
  }
  void changed() {widget.store.setDraft('business', snapshot()); setState(() {});}
  @override
  void dispose() {for (final x in f.values) x.dispose(); super.dispose();}
  Widget field(String key, String title, {String? suffix, bool integer = false}) =>
    NumberField(label: title, controller: f[key]!, onChanged: changed, suffix: suffix, integer: integer);
  Widget gap() => const SizedBox(height: 10);
  String euros(Dec amount) => money(amount, widget.store);


  @override
  Widget build(BuildContext context) {
    final r = calculation, tax = taxResult;
    final hasTax = tax?.estimated == true;
    final monthTax = hasTax ? tax!.yearlyBusinessTax / Dec.fromInt(12) : Dec.zero;
    final takeHome = hasTax ? tax!.yearlyAfterTax / Dec.fromInt(12) : (r?.operatingProfit ?? Dec.zero);
    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 44), children: [
        Row(children: [
          Expanded(child: Text('AXREON',style: const TextStyle(
            fontSize: 29, letterSpacing: -1.1, fontWeight: FontWeight.w700))),
          IconButton(onPressed: scenarios,tooltip:'Saved scenarios',
            icon: const Icon(Icons.bookmarks_outlined)),
        ]),
        const SizedBox(height: 31),
        if (r == null)
          const Hint('Enter valid customer counts and prices.')
        else ...[
          HeroFigure(
            caption: taxMode == TaxMode.bv ? 'Remaining in BV / month' : 'Estimated net / month',
            value: hasTax ? euros(takeHome) : '—',
            color: accent,
            supporting: hasTax ? '${r.totalClients} paying clients · ${taxYear == 2026 ? "2026" : "tax rates unavailable"}'
              : 'Set a supported tax year to estimate',
          ),
          const SizedBox(height: 25),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: InlineStat(label:'Revenue',value:euros(r.monthlyRevenue))),
            const SizedBox(width: 14),
            Expanded(child: InlineStat(label:'Costs',value:euros(r.monthlyExpenses))),
          ]),
          const SizedBox(height: 19),
          Row(crossAxisAlignment: CrossAxisAlignment.start,children:[
            Expanded(child: InlineStat(label:'Operating profit',
              value:euros(r.operatingProfit))),
            const SizedBox(width: 14),
            Expanded(child: InlineStat(label:'Tax reserve',
              value:hasTax ? euros(monthTax) : '—')),
          ]),
          const SizedBox(height: 28),
          Divider(height: 1,color:Theme.of(context).dividerColor),
        ],
        const SectionHead('Subscriptions'),
        KCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
          if (!advanced) ...[
            field('clients', 'Paying clients',integer:true),
            const SizedBox(height: 22),
            KSelect<String>(
              label:'Subscription plan',value:selectedPlan,
              options:const [KSelectOption('basic','Basic'),KSelectOption('medium','Medium'),KSelectOption('pro','Pro')],
              onChanged:(x){selectedPlan=x;changed();}),
          ] else ...[
            Row(children: [
              Expanded(child:field('basicClients','Basic',integer:true)),
              const SizedBox(width:8),
              Expanded(child:field('mediumClients','Medium',integer:true)),
              const SizedBox(width:8),
              Expanded(child:field('proClients','Pro',integer:true)),
            ]),
          ],
          const SizedBox(height: 7),
          SwitchListTile(
            dense:true,contentPadding:EdgeInsets.zero,
            title:const Text('Mix subscription plans',
              style:TextStyle(fontSize:14.5,fontWeight:FontWeight.w600)),
            value:advanced,onChanged:(x){advanced=x;changed();}),
        ])),
        ExpansionTile(
          tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:12),
          shape:const Border(),collapsedShape:const Border(),
          title:const Text('Pricing & VAT settings',style:TextStyle(fontWeight:FontWeight.w600,fontSize:14.5)),
          leading:const Icon(Icons.tune_outlined,size:20),
          children:[
            Row(children: [
              Expanded(child:field('basic','Basic',suffix:'€')),
              const SizedBox(width:8),
              Expanded(child:field('medium','Medium',suffix:'€')),
              const SizedBox(width:8),
              Expanded(child:field('pro','Pro',suffix:'€')),
            ]),
            const SizedBox(height:12),
            SwitchListTile(dense:true,contentPadding:EdgeInsets.zero,
              title:const Text('Prices include VAT',
                style:TextStyle(fontWeight:FontWeight.w600,fontSize:14.5)),
              value:vatIncluded,onChanged:(x){vatIncluded=x;changed();}),
            field('vat','VAT rate',suffix:'%'),
          ]),
        SectionHead('Expenses',action: TextButton.icon(
          onPressed:()=>editExpense(null),
          icon:const Icon(Icons.add,size:17),label:const Text('Add'))),
        if (r != null)
          Padding(padding:const EdgeInsets.only(bottom:10),
            child: HeroFigure(caption:'Monthly operating costs',
              value:euros(r.monthlyExpenses))),
        for (final expense in expenses) ...[
          ListTile(
            contentPadding:EdgeInsets.zero,dense:true,
            onTap:()=>editExpense(expense),
            title:Text(expense.name,style:TextStyle(fontWeight:FontWeight.w600,
              decoration:expense.enabled ? null:TextDecoration.lineThrough)),
            subtitle:Text(expense.frequency.name,style:TextStyle(color:muted(context))),
            trailing:Text(euros(expense.monthlyAmount()),
              style:const TextStyle(fontWeight:FontWeight.w700)),
          ),
          Divider(height:1,color:Theme.of(context).dividerColor),
        ],
        const SizedBox(height:12),
        ExpansionTile(
          tilePadding:EdgeInsets.zero,shape:const Border(),collapsedShape:const Border(),
          title:const Text('Payment processing',style:TextStyle(fontSize:14.5,fontWeight:FontWeight.w600)),
          leading:const Icon(Icons.credit_card_outlined,size:20),
          childrenPadding:const EdgeInsets.only(bottom:12),
          children:[
            field('providerPercent','Fee / transaction',suffix:'%'),
            const SizedBox(height:12),
            Row(children:[
              Expanded(child:field('providerFixed','Fixed fee',suffix:'€')),
              const SizedBox(width:12),
              Expanded(child:field('transactions','Transactions',integer:true)),
            ]),
            if(r!=null) Padding(padding:const EdgeInsets.only(top:14),
              child:_pair('Monthly fees',euros(r.processingFees))),
          ]),
        SectionHead('Tax estimate',action: TextButton(
          onPressed:()=> _openTaxHelp(context),
          child:const Text('Info'))),
        if (r!=null && tax!=null)...[
          Row(children:[
            Expanded(child:InlineStat(label:'Yearly operating profit',value:euros(r.annualProfit))),
            const SizedBox(width:12),
            Expanded(child:InlineStat(label:'Estimated yearly tax',
              value:hasTax?euros(tax.yearlyBusinessTax):'—')),
          ]),
          const SizedBox(height:10),
          Text('These amounts are estimates, not a tax assessment.',
            style:TextStyle(fontSize:12,color:muted(context))),
        ],
        const SizedBox(height:13),
        KCard(child:Column(children:[
          KSelect<TaxMode>(label:'Business tax model',value:taxMode,
            options:const [KSelectOption(TaxMode.simple,'Simple reserve'),
              KSelectOption(TaxMode.soleTrader,'Eenmanszaak · Box 1'),
              KSelectOption(TaxMode.bv,'BV · Corporate')],
            onChanged:(v){taxMode=v;changed();}),
          const SizedBox(height:12),
          if(taxMode==TaxMode.simple)
            field('taxEffective','Tax reserve',suffix:'%'),
          if(taxMode!=TaxMode.simple)...[
            KSelect<int>(label:'Tax year',value:taxYear,
              options:const [KSelectOption(2026,'2026'),KSelectOption(2027,'2027 · not yet configured')],
              onChanged:(v){taxYear=v;changed();}),
            const SizedBox(height:12),
          ],
          if(taxMode==TaxMode.soleTrader)...[
            ExpansionTile(tilePadding:EdgeInsets.zero,
              shape:const Border(),collapsedShape:const Border(),
              title:const Text('Deductions & eligibility',style:TextStyle(fontSize:14,fontWeight:FontWeight.w600)),
              children:[
                field('otherIncome','Other taxable income',suffix:'€'),gap(),
                field('deductions','Other deductions',suffix:'€'),gap(),
                field('credits','Allocated credits',suffix:'€'),gap(),
                _taxSwitch('Eligible entrepreneur',entrepreneur,(v){entrepreneur=v;changed();}),
                _taxSwitch('Hours criterion',hours,(v){hours=v;changed();}),
                _taxSwitch('Starter allowance',starter,(v){starter=v;changed();}),
                _taxSwitch('MKB exemption',mkb,(v){mkb=v;changed();}),
                _taxSwitch('Zvw contribution',zvw,(v){zvw=v;changed();}),
              ]),
          ],
          if(taxMode==TaxMode.bv)...[
            field('salary','Director salary',suffix:'€'),gap(),
            field('dividends','Planned dividends',suffix:'€'),
            const Hint('BV profit is not personal take-home pay.'),
          ],
        ])),
        ExpansionTile(
          tilePadding:EdgeInsets.zero,shape:const Border(),collapsedShape:const Border(),
          leading:const Icon(Icons.receipt_long_outlined,size:20),
          title:const Text('VAT breakdown',style:TextStyle(fontSize:14.5,fontWeight:FontWeight.w600)),
          children:[if(r!=null)...[
            _pair('Invoiced incl. VAT',euros(r.invoiced)),
            _pair('Output VAT',euros(r.outputVat)),
            _pair('Recoverable input VAT',euros(r.inputVat)),
            const Divider(),
            _pair('Estimated VAT payable',euros(r.netVat),emphasis:true),
            const SizedBox(height:14),
          ]]),
        const SectionHead('Growth'),
        KCard(child:Column(children:[
          SwitchListTile(
            dense:true,contentPadding:EdgeInsets.zero,
            title:const Text('12-month projection',style:TextStyle(fontWeight:FontWeight.w600)),
            value:showGrowth,onChanged:(x){showGrowth=x;setState((){});}),
          if(showGrowth)...[
            field('growthNew','New clients / month',integer:true),gap(),
            Row(children:[
              Expanded(child:field('growthChurn','Churn',suffix:'%')),
              const SizedBox(width:12),
              Expanded(child:field('growthCost','Cost growth',suffix:'%')),
            ]),
            if(r!=null)_buildGrowth(r),
          ],
        ])),
        const SizedBox(height:8),
        ExpansionTile(
          shape:const Border(),collapsedShape:const Border(),
          tilePadding:EdgeInsets.zero,
          title:const Text('Compare scenarios',style:TextStyle(fontWeight:FontWeight.w600,fontSize:14.5)),
          children:[
            field('compareClients','Comparison clients',integer:true),
            if(r!=null)...[const SizedBox(height:12),_compare(r)],
          ]),
        const SizedBox(height:26),
        Row(children:[
          Expanded(child:OutlinedButton.icon(
            onPressed:r==null||tax==null||!tax.estimated?null:()=>export(false,r,tax),
            icon:const Icon(Icons.file_download_outlined,size:18),
            label:const Text('CSV'))),
          const SizedBox(width:12),
          Expanded(child:FilledButton.icon(
            onPressed:r==null||tax==null||!tax.estimated?null:()=>export(true,r,tax),
            icon:const Icon(Icons.ios_share_outlined,size:18),
            label:const Text('Share PDF'))),
        ]),
        const SizedBox(height:10),
        TextButton.icon(onPressed:saveScenario,
          icon:const Icon(Icons.bookmark_add_outlined,size:18),
          label:const Text('Save scenario')),
        const SizedBox(height:10),
        const Hint('Financial forecast only. Tax depends on actual eligibility, credits, other income and circumstances.'),
      ]);
  }

  Widget _taxSwitch(String title,bool value,ValueChanged<bool> onChanged) =>
    SwitchListTile(dense:true,contentPadding:EdgeInsets.zero,
      title:Text(title,style:const TextStyle(fontSize:14)),
      value:value,onChanged:onChanged);

  void _openTaxHelp(BuildContext context) =>
    showModalBottomSheet<void>(context:context,showDragHandle:true,
      builder:(ctx)=>SafeArea(child:Padding(
        padding:const EdgeInsets.fromLTRB(24,14,24,35),child:Column(
          mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            const Text('Tax estimates',style:TextStyle(fontSize:23,fontWeight:FontWeight.w700)),
            const SizedBox(height:14),
            Text(taxResult?.explanation ?? 'Review tax inputs for your circumstances.',
              style:const TextStyle(height:1.5)),
            const SizedBox(height:20),
            const Text('VAT is not business income. BV retained profits are not personal income.'),
          ]))));
  Widget _pair(String label,String value,{bool emphasis=false}) =>
    Padding(padding: const EdgeInsets.symmetric(vertical:7),child:Row(children:[
      Expanded(child:Text(label,style:TextStyle(fontSize:12.5,color:Theme.of(context).hintColor))),
      Text(value,style:TextStyle(fontWeight:FontWeight.w800,color:emphasis?accent:null))]));

  Widget _compare(BusinessResult original) {
    try {
      final count = n('compareClients');
      if (count < 0) return const Text('Enter a valid number of clients');
      final cmp = calculateBusiness(BusinessInput(clients:[0,count,0],
        prices:[v('basic'),v('medium'),v('pro')], expenses:expenses,
        vatRate:v('vat'),providerPercent:v('providerPercent'),providerFixed:v('providerFixed'),
        monthlyTransactions:n('transactions'),pricesIncludeVat:vatIncluded));
      return Column(children:[
        _pair('Your current scenario · monthly revenue',euros(original.monthlyRevenue)),
        _pair('$count Medium clients · monthly revenue',euros(cmp.monthlyRevenue)),
        _pair('Difference · monthly revenue',euros(cmp.monthlyRevenue-original.monthlyRevenue),emphasis:true),
        _pair('Difference · operating profit',euros(cmp.operatingProfit-original.operatingProfit)),
        if (taxes != null && taxYear == 2026) _pair('Difference · after-tax (annual)',
          euros(estimateTax(cmp.annualProfit, taxes!).yearlyAfterTax -
            estimateTax(original.annualProfit, taxes!).yearlyAfterTax)),
        const Hint('Comparison always uses the Medium subscription at its current editable price.'),
      ]);
    } catch (_) {return const Hint('Comparison unavailable until inputs are valid.');}
  }

  Widget _buildGrowth(BusinessResult base) {
    try {
      final avg = base.totalClients > 0 ? base.monthlyRevenue / Dec.fromInt(base.totalClients) : v('medium');
      final rows = simulateGrowth(startClients:base.totalClients,newClients:n('growthNew'),
        churnPercent:v('growthChurn'),price:avg,
        startingExpenses:base.monthlyExpenses,expenseGrowthPercent:v('growthCost'),
        effectiveTaxPercent:v('taxEffective'));
      return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const SizedBox(height:14),
        ChartLine(values:rows.map((row)=>row.revenue.toDouble()).toList()),
        const SizedBox(height:10),
        _pair('Month 12 · customers','${rows.last.clients}'),
        _pair('Month 12 · MRR',euros(rows.last.revenue)),
        _pair('Month 12 · ARR run-rate',euros(rows.last.revenue*Dec.fromInt(12))),
        _pair('Cumulative 12-month net',euros(rows.last.cumulative),emphasis:true),
        const SizedBox(height:8),
        ...rows.map((row)=>ExpansionTile(tilePadding:EdgeInsets.zero,
          title:Text('Month ${row.month}  ·  ${row.clients} clients',style:const TextStyle(fontWeight:FontWeight.w700)),
          subtitle:Text(euros(row.revenue)),
          children:[_pair('Revenue',euros(row.revenue)),_pair('Expenses',euros(row.expenses)),
            _pair('Operating profit',euros(row.operating)),
            _pair('Illustrative tax',euros(row.estimatedTax)),
            _pair('Net',euros(row.net)),_pair('Cumulative',euros(row.cumulative))])),
        const Hint('Growth uses a simple monthly effective tax reserve, not final personal tax. Customers are rounded to whole numbers each month.'),
      ]);
    } catch (_) {return const Hint('Enter valid growth inputs.');}
  }

  Future<void> editExpense(BusinessExpense? expense) async {
    final name = TextEditingController(text:expense?.name ?? '');
    final amount = TextEditingController(text:expense?.amount.toFixed(2) ?? '0');
    var frequency = expense?.frequency ?? ExpenseFrequency.monthly;
    var vat = expense?.vatTreatment ?? ExpenseVat.exempt;
    var enabled = expense?.enabled ?? true;
    final outcome = await showDialog<String>(context:context,builder:(dialog) => StatefulBuilder(
      builder:(dialog,setModalState) => AlertDialog(title:Text(expense == null ? 'New expense' : 'Edit expense'),
        content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:name,decoration:const InputDecoration(labelText:'Name')),
          const SizedBox(height:10),
          TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),
            decoration:const InputDecoration(labelText:'Amount (€)')),
          const SizedBox(height:10),
          KSelect<ExpenseFrequency>(label:'Frequency',value:frequency,
            options:ExpenseFrequency.values.map((v)=>KSelectOption(v,v.name)).toList(),
            onChanged:(x)=>setModalState(()=>frequency=x)),
          const SizedBox(height:10),
          KSelect<ExpenseVat>(label:'VAT treatment',value:vat,
            options:ExpenseVat.values.map((v)=>KSelectOption(v,v.name)).toList(),
            onChanged:(x)=>setModalState(()=>vat=x)),
          SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Active'),value:enabled,
            onChanged:(x)=>setModalState(()=>enabled=x)),
        ])),actions:[
          if(expense!=null)TextButton(onPressed:()=>Navigator.pop(dialog,'delete'),child:const Text('Delete')),
          TextButton(onPressed:()=>Navigator.pop(dialog),child:const Text('Cancel')),
          FilledButton(onPressed:()=>Navigator.pop(dialog,'save'),child:const Text('Save')),
        ])));
    if (outcome == 'delete' && expense!=null) {expenses.removeWhere((e)=>e.id==expense.id);changed();}
    if (outcome == 'save') {
      Dec parsed;
      try {parsed = Dec.parse(amount.text);if(parsed<Dec.zero)throw ArgumentError('Negative');}
      catch (_) {if(mounted)notice(context,'Please enter a valid non-negative amount');name.dispose();amount.dispose();return;}
      if(name.text.trim().isEmpty){if(mounted)notice(context,'Expense name is required');name.dispose();amount.dispose();return;}
      final item=BusinessExpense(id:expense?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name:name.text.trim(),amount:parsed,frequency:frequency,vatTreatment:vat,enabled:enabled);
      if(expense!=null)expenses.removeWhere((e)=>e.id==expense.id);
      expenses.add(item);changed();
    }
    name.dispose();amount.dispose();
  }

  Future<void> export(bool pdf,BusinessResult r,TaxResult t) async {
    final now=DateTime.now().millisecondsSinceEpoch;
    final rows=[['Measure','Monthly','Yearly'],
      ['Clients','${r.totalClients}',''],
      ['Revenue ex VAT',r.monthlyRevenue.toFixed(2),(r.monthlyRevenue*Dec.fromInt(12)).toFixed(2)],
      ['Expenses ex VAT',r.monthlyExpenses.toFixed(2),(r.monthlyExpenses*Dec.fromInt(12)).toFixed(2)],
      ['Operating profit',r.operatingProfit.toFixed(2),r.annualProfit.toFixed(2)],
      ['Estimated tax',(t.yearlyBusinessTax/Dec.fromInt(12)).toFixed(2),t.yearlyBusinessTax.toFixed(2)],
      ['After tax',(t.yearlyAfterTax/Dec.fromInt(12)).toFixed(2),t.yearlyAfterTax.toFixed(2)],
      ['Output VAT',r.outputVat.toFixed(2),(r.outputVat*Dec.fromInt(12)).toFixed(2)],
      ['Input VAT',r.inputVat.toFixed(2),(r.inputVat*Dec.fromInt(12)).toFixed(2)],
      ['VAT due',r.netVat.toFixed(2),(r.netVat*Dec.fromInt(12)).toFixed(2)]];
    try {
      if(pdf) {
        await Reports.savePdf('kalqo_axreon_$now.pdf',[
          'KALQO / AXREON BUSINESS REPORT',
          'Tax mode: ${taxMode.name}; year: $taxYear',
          'VAT rate: ${f['vat']!.text}%',
          ...rows.map((e)=>e.join(' | ')), '', t.explanation,
          'Forecast only; actual taxes and accounting may differ.'],widget.store);
      } else {
        await Reports.saveCsv('kalqo_axreon_$now.csv',rows,widget.store);
      }
      if(mounted)notice(context,'Report saved / share options opened');
    }catch(e){if(mounted)notice(context,'Export failed: $e');}
  }

  Future<void> saveScenario() async {
    final name = await askName(context,'Save AXREON scenario');
    if(name!=null){widget.store.addScenario('business',name,snapshot());if(mounted)notice(context,'Scenario saved');}
  }
  void scenarios(){
    final entries=widget.store.scenarios.where((s)=>s['kind']=='business').toList();
    showModalBottomSheet<void>(context:context,showDragHandle:true,builder:(ctx)=>SafeArea(
      child:ListView(shrinkWrap:true,children:[
        const ListTile(title:Text('Saved AXREON scenarios',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800))),
        if(entries.isEmpty)const ListTile(title:Text('No saved scenarios')),
        ...entries.map((s)=>ListTile(title:Text('${s['name']}'),
          subtitle:Text('${s['saved']}'.split('T').first),
          onTap:(){restore(Map<String,dynamic>.from(s['data'] as Map));changed();Navigator.pop(ctx);},
          trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){
            widget.store.removeScenario('${s['id']}');Navigator.pop(ctx);scenarios();}))),
      ])));
  }
}
