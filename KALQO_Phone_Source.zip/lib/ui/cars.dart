import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/storage.dart';
import '../core/vehicle.dart';
import 'common.dart';

/// Red and orange reflect ONLY the user's inspection notes; never API accident records.
enum PanelCondition { unknown, damage, repainted, clear }

const panels = <String>[
  'Front bumper', 'Bonnet', 'Roof', 'Boot', 'Rear bumper',
  'Left front door', 'Right front door', 'Left rear door', 'Right rear door',
];

class CarsPage extends StatefulWidget {
  final AppStore store;
  const CarsPage({super.key, required this.store});
  @override State<CarsPage> createState() => _CarsPageState();
}

class _CarsPageState extends State<CarsPage> {
  final query = TextEditingController();
  final mileage = TextEditingController();
  final inspectionNote = TextEditingController();
  String country = 'NL';
  bool busy = false, editMode = false;
  VehicleRecord? car;
  String? error;
  final Map<String, PanelCondition> selected = {};
  String get vehicleKey => '$country:${query.text.trim().toUpperCase()}';

  @override void initState() {
    super.initState();
    final draft = widget.store.drafts['cars'];
    if (draft is Map) {
      country = '${draft['country'] ?? 'NL'}';
      query.text = '${draft['query'] ?? ''}';
      mileage.text = '${draft['mileage'] ?? ''}';
      inspectionNote.text = '${draft['note'] ?? ''}';
      restoreInspection();
    }
  }
  @override void dispose() { query.dispose(); mileage.dispose(); inspectionNote.dispose(); super.dispose(); }
  void restoreInspection() {
    selected.clear();
    mileage.clear();
    inspectionNote.clear();
    final all=widget.store.drafts['carInspections'];
    final data=all is Map ? all[vehicleKey] : null;
    if(data is! Map)return;
    mileage.text='${data['mileage']??''}';
    inspectionNote.text='${data['note']??''}';
    final parts=data['panels'];
    if(parts is Map){
      for(final entry in parts.entries){
        final ix=PanelCondition.values.indexWhere((x)=>x.name==entry.value);
        if(ix>=0 && panels.contains(entry.key))selected['${entry.key}']=PanelCondition.values[ix];
      }
    }
  }
  void save(){
    widget.store.setDraft('cars',{'country':country,'query':query.text});
    if(query.text.trim().isEmpty)return;
    final all=Map<String,dynamic>.from(widget.store.drafts['carInspections'] is Map
      ? widget.store.drafts['carInspections'] as Map: {});
    all[vehicleKey]={'mileage':mileage.text,'note':inspectionNote.text,
      'panels':selected.map((k,v)=>MapEntry(k,v.name))};
    widget.store.setDraft('carInspections',all);
  }
  void changeQuery(String value){
    // Never show one car's inspection marks on another vehicle.
    setState(() {car=null;error=null;restoreInspection();});
    widget.store.setDraft('cars',{'country':country,'query':query.text});
  }

  Future<void> lookup() async {
    FocusScope.of(context).unfocus();
    if (country == 'DE') {
      setState(() {car=null;error='German plate data is not publicly searchable. Use the inspection diagram below for your own notes; verified history requires an authorized provider.';});
      return;
    }
    setState(() {busy=true;error=null;car=null;});
    save();
    try {
      final found = country == 'NL' ? await VehicleApi.dutchPlate(query.text)
        : await VehicleApi.americanVin(query.text);
      if (!mounted) return;
      setState(() {car=found;busy=false;});
    } on VehicleLookupException catch(e) {
      if (mounted) setState(() {error=e.message;busy=false;});
    } catch(_) {
      if (mounted) setState(() {error='Lookup failed. Please try again.';busy=false;});
    }
  }
  @override Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final labelColor = muted(context);
    final c = car;
    return ListView(
      padding: const EdgeInsets.fromLTRB(24,21,24,50),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      children: [
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
          const Text('Garage',style:TextStyle(fontSize:32,fontWeight:FontWeight.w700,letterSpacing:-1.35)),
          Text('VEHICLE INTELLIGENCE',style:TextStyle(fontSize:10,color:labelColor,letterSpacing:1.4,fontWeight:FontWeight.w700)),
        ]),
        const SizedBox(height:7),
        Text('One plate. A clearer picture.',style:TextStyle(fontSize:14,color:labelColor)),
        const SizedBox(height:32),
        Kicker('LOOKUP REGION'),
        const SizedBox(height:12),
        Row(children:[
          for(final region in [('NL','Netherlands'),('DE','Germany'),('US','United States')])...[
            Expanded(child:KOptionPill(label:region.$1,selected:country==region.$1,
              onTap:(){setState(() {country=region.$1;car=null;error=null;restoreInspection();});save();})),
            if(region.$1!='US')const SizedBox(width:9),
          ],
        ]),
        const SizedBox(height:24),
        Text(country=='US'?'17-character VIN': 'License plate', style:TextStyle(color:labelColor,fontSize:12)),
        const SizedBox(height:9),
        Row(children:[
          Expanded(child:TextField(controller:query,
            textCapitalization:TextCapitalization.characters,
            textInputAction:TextInputAction.search,
            inputFormatters:[LengthLimitingTextInputFormatter(country=='US'?17:16)],
            onSubmitted:(_)=>lookup(),onChanged:changeQuery,
            style:const TextStyle(fontWeight:FontWeight.w700,letterSpacing:1.1,fontSize:21),
            decoration:InputDecoration(hintText:country=='NL'?'XX-999-X':country=='US'?'1HGCM82633A004352':'B-AB 1234',
              contentPadding:const EdgeInsets.fromLTRB(17,16,9,16),
              suffixIcon:IconButton(icon:const Icon(Icons.close_rounded,size:19),
                onPressed:(){query.clear();setState((){car=null;error=null;restoreInspection();});save();}),
            ))),
          const SizedBox(width:10),
          SizedBox(height:57,width:57,child:FilledButton(
            style:FilledButton.styleFrom(padding:EdgeInsets.zero,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17))),
            onPressed:busy?null:lookup,
            child:busy?const SizedBox(height:20,width:20,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)):
              const Icon(Icons.arrow_forward_rounded,size:24))),
        ]),
        const SizedBox(height:12),
        Text(country=='NL'?'Official RDW registration data · internet required':
          country=='US'?'Official NHTSA VIN data · plates are not supported':
          'German registration lookup requires an authorized data provider',
          style:TextStyle(color:labelColor,fontSize:11.5)),
        if(error!=null)...[
          const SizedBox(height:19),
          Text(error!,style:TextStyle(fontSize:13,color:isDark?const Color(0xFFFBA8A4):const Color(0xFFB9232E),height:1.5)),
        ],
        if (c != null) ...[
          const SizedBox(height:38),
          const Kicker('VEHICLE'),
          const SizedBox(height:8),
          Text('${c.make} ${c.model}'.trim(),style:const TextStyle(fontSize:28,fontWeight:FontWeight.w700,letterSpacing:-.85)),
          const SizedBox(height:10),
          Text('${c.identifier}  ·  ${c.year.isEmpty?'Year not listed':c.year}',style:TextStyle(color:labelColor,fontSize:14)),
          const SizedBox(height:11),
          Text('Accident history · Not verified',style:TextStyle(fontSize:12,color:labelColor)),
          const SizedBox(height:26),
          Divider(color:Theme.of(context).dividerColor,height:1),
          const SizedBox(height:17),
          Wrap(runSpacing:18,children:[
            _stat('Body',c.bodyType),_stat('Fuel',c.fuel),
            _stat('Color',c.color),_stat('Engine',c.engine.isEmpty?'—':'${c.engine} ${c.source.startsWith('RDW')?'cc':'L'}'),
            _stat('First registration',c.registration),_stat('Inspection / APK',c.apk),
          ]),
          const SizedBox(height:17),
          ExpansionTile(tilePadding:EdgeInsets.zero,shape:const Border(),collapsedShape:const Border(),
            title:const Text('More technical details',style:TextStyle(fontWeight:FontWeight.w600,fontSize:14.5)),
            children:[Padding(padding:const EdgeInsets.only(bottom:18),child:
              Wrap(runSpacing:18,children:[
                _stat('Weight',c.weight.isEmpty?'—':'${c.weight} kg'),
                _stat('Power ratio / HP',c.power),
                _stat('Efficiency',c.emissions),
                if(c.vin.isNotEmpty)_stat('VIN',c.vin),
              ]))]),
          const SizedBox(height:10),
          Divider(color:Theme.of(context).dividerColor,height:1),
          const SizedBox(height:19),
          Kicker('ODOMETER RECORD'),
          const SizedBox(height:10),
          Text(c.odometerJudgement.isEmpty?'Not provided':c.odometerJudgement,
            style:const TextStyle(fontSize:21,fontWeight:FontWeight.w600)),
          const SizedBox(height:5),
          Text(c.odometerYear.isEmpty?'Exact current mileage not available from this public source':
            'Last registered assessment year: ${c.odometerYear} · No exact current reading',
            style:TextStyle(color:labelColor,fontSize:12.5,height:1.5)),
          const SizedBox(height:9),
          Text('Source: ${c.source}',style:TextStyle(color:labelColor,fontSize:11.5)),
        ],
        const SizedBox(height:42),
        Row(children:[
          const Expanded(child:Text('Condition map',style:TextStyle(fontSize:22,fontWeight:FontWeight.w700,letterSpacing:-.65))),
          TextButton.icon(onPressed:(){setState(()=>editMode=!editMode);},
            icon:Icon(editMode?Icons.check:Icons.edit_outlined,size:17),
            label:Text(editMode?'Done':'Edit')),
        ]),
        const SizedBox(height:6),
        Text('Personal inspection notes · not an official accident report',
          style:TextStyle(color:labelColor,fontSize:12.5)),
        const SizedBox(height:21),
        Center(child:VehicleDiagram(conditions:selected,
          onPartTap:editMode?(p){setState(() {
            final current=selected[p]??PanelCondition.unknown;
            selected[p]=PanelCondition.values[(current.index+1)%PanelCondition.values.length];
          });save();}:null)),
        const SizedBox(height:9),
        Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[
          _legend(const Color(0xFFE45858),'Damage'),
          _legend(const Color(0xFFED9B4F),'Repainted'),
          _legend(isDark?const Color(0xFF616D7A):const Color(0xFFBBC3CC),'Unknown'),
        ]),
        const SizedBox(height:13),
        Text(editMode?'Tap a panel to cycle: Unknown → Damage → Repainted → Checked clear.':
          'Tap Edit to mark panels you have personally inspected.',
          style:TextStyle(fontSize:12,color:labelColor),textAlign:TextAlign.center),
        const SizedBox(height:25),
        const SectionHead('Inspection notes'),
        NumberField(label:'Observed mileage (manual)',controller:mileage,
          onChanged:save, suffix:'km',integer:true),
        const SizedBox(height:16),
        TextField(controller:inspectionNote,maxLines:3,minLines:2,onChanged:(_)=>save(),
          decoration:const InputDecoration(labelText:'Notes',hintText:'Add observations, date and source...')),
        const SizedBox(height:23),
        Text('Accident and repaint history cannot be confirmed from RDW or NHTSA public lookups. Any colored panels are saved inspection notes entered on this phone.',
          style:TextStyle(color:labelColor,fontSize:12.5,height:1.55)),
      ]);
  }
  Widget _stat(String label,String value) => SizedBox(width:MediaQuery.of(context).size.width*.42,
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(label,style:TextStyle(fontSize:11,color:muted(context))),const SizedBox(height:5),
      Text(value.isEmpty?'—':value,maxLines:2,overflow:TextOverflow.ellipsis,
        style:const TextStyle(fontSize:14,fontWeight:FontWeight.w600)),
    ]));
  Widget _legend(Color color,String label)=>Row(mainAxisSize:MainAxisSize.min,children:[
    Container(height:9,width:9,decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(3))),
    const SizedBox(width:6),Text(label,style:TextStyle(fontSize:11.5,color:muted(context))),
  ]);
}

class VehicleDiagram extends StatelessWidget {
  final Map<String,PanelCondition> conditions;
  final ValueChanged<String>? onPartTap;
  const VehicleDiagram({super.key,required this.conditions,this.onPartTap});
  @override Widget build(BuildContext context) => SizedBox(width:240,height:395,
    child:GestureDetector(behavior:HitTestBehavior.opaque,
      onTapUp:(details){
        if(onPartTap==null)return;
        final p=details.localPosition;
        final part=partForPoint(p.dx/240,p.dy/395);
        if(part!=null)onPartTap!(part);
      },
      child:CustomPaint(painter:_VehiclePainter(Map<String,PanelCondition>.from(conditions),
        Theme.of(context).brightness==Brightness.dark))));

  static String? partForPoint(double x,double y){
    // Stable normalized hit targets; front is at the top.
    if (x<.13 || x>.87 || y<.04 || y>.96) return null;
    if(y<.115) return panels[0];
    if(y<.305) return panels[1];
    if(y<.66){
      if(x<.305)return y<.47?panels[5]:panels[7];
      if(x>.695)return y<.47?panels[6]:panels[8];
      return panels[2];
    }
    if(y<.87)return panels[3];
    return panels[4];
  }
}

class _VehiclePainter extends CustomPainter {
  final Map<String,PanelCondition> values;
  final bool dark;
  _VehiclePainter(this.values,this.dark);
  Color color(String name){
    switch(values[name]??PanelCondition.unknown){
      case PanelCondition.damage:return const Color(0xFFE45858);
      case PanelCondition.repainted:return const Color(0xFFED9B4F);
      case PanelCondition.clear:return dark?const Color(0xFF345A4A):const Color(0xFFC5DFD4);
      case PanelCondition.unknown:return dark?const Color(0xFF242F39):const Color(0xFFE6EBF0);
    }
  }
  @override void paint(Canvas canvas,Size size){
    canvas.save();canvas.scale(size.width/240,size.height/395);
    final line=Paint()
      ..color=(dark?const Color(0xFF64717E):const Color(0xFFA4B0BB))
      ..style=PaintingStyle.stroke..strokeWidth=1.5;
    void rr(String name,Rect bounds,double radius){
      final shape=RRect.fromRectAndRadius(bounds,Radius.circular(radius));
      canvas.drawRRect(shape,Paint()..color=color(name));canvas.drawRRect(shape,line);
    }
    final chassis=RRect.fromRectAndRadius(const Rect.fromLTWH(31,8,178,379),const Radius.circular(59));
    canvas.drawRRect(chassis,Paint()..color=dark?const Color(0xFF131B24):const Color(0xFFF0F3F5));
    canvas.drawRRect(chassis,line);
    final wheelPaint=Paint()..color=dark?const Color(0xFF070B11):const Color(0xFF343D48);
    for(final y in [78.0,293.0]){
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(24,y,17,51),const Radius.circular(7)),wheelPaint);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(199,y,17,51),const Radius.circular(7)),wheelPaint);
    }
    rr(panels[0],const Rect.fromLTWH(52,14,136,29),19);
    rr(panels[1],const Rect.fromLTWH(51,49,138,70),22);
    rr(panels[5],const Rect.fromLTWH(38,126,34,61),10);
    rr(panels[6],const Rect.fromLTWH(168,126,34,61),10);
    rr(panels[7],const Rect.fromLTWH(38,191,34,65),10);
    rr(panels[8],const Rect.fromLTWH(168,191,34,65),10);
    rr(panels[2],const Rect.fromLTWH(76,126,88,137),18);
    rr(panels[3],const Rect.fromLTWH(51,269,138,67),22);
    rr(panels[4],const Rect.fromLTWH(52,346,136,32),18);
    final glass=Paint()..color=dark?const Color(0xFF090D12):const Color(0xFFBCC7D0);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(77,131,86,23),const Radius.circular(10)),glass);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(77,237,86,22),const Radius.circular(10)),glass);
    canvas.restore();
  }
  @override bool shouldRepaint(covariant _VehiclePainter old) =>
    old.dark!=dark || old.values.toString()!=values.toString();
}
