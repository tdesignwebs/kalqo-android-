import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class SettingsPage extends StatefulWidget {
  final AppStore store;
  const SettingsPage({super.key, required this.store});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final Map<String, TextEditingController> controls;
  static const labels = <String, String>{
    'bankRate':'Default annual bank interest (%)',
    'bankTax':'Default Turkish withholding (%)',
    'bankDays':'Default deposit term (days)',
    'vatRate':'Dutch VAT (%)',
    'basicPrice':'Basic subscription (€)',
    'mediumPrice':'Medium subscription (€)',
    'proPrice':'Pro subscription (€)',
  };
  static const defaults = <String, String>{
    'bankRate':'32','bankTax':'17.5','bankDays':'31','vatRate':'21',
    'basicPrice':'39','mediumPrice':'59','proPrice':'79',
  };
  @override
  void initState() {
    super.initState();
    controls = {for(final key in labels.keys) key: TextEditingController(text:widget.store.preferences[key] ?? defaults[key])};
  }
  @override
  void dispose() {
    for(final c in controls.values) { c.dispose(); }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store=widget.store;
    return Scaffold(
      appBar:AppBar(title:Text(tr(store,'Settings','Instellingen','Ayarlar')),
        titleTextStyle:TextStyle(color:Theme.of(context).colorScheme.onSurface,
          fontSize:21,fontWeight:FontWeight.w700)),
      body:ListView(
        padding:const EdgeInsets.fromLTRB(24,10,24,44),
        children:[
          const SectionHead('Appearance'),
          const SizedBox(height:5),
          Row(children:[
            for(final t in ['light','dark','system'])...[
              Expanded(child:KOptionPill(label:t=='light'?'Light':t=='dark'?'Dark':'Auto',
                selected:store.theme==t,onTap:(){store.update(newTheme:t);setState((){});})),
              if(t!='system')const SizedBox(width:8),
            ],
          ]),
          const SizedBox(height:12),
          const SectionHead('Preferences'),
          KSelect<String>(label:'Language',value:store.language,
            options:const [KSelectOption('nl','Nederlands'), KSelectOption('en','English'),KSelectOption('tr','Türkçe')],
            onChanged:(x){store.update(newLanguage:x);setState((){});}),
          const SizedBox(height:13),
          KSelect<int>(label:'Decimal places',value:store.decimals,
            options:[for(final d in [0,1,2,3,4]) KSelectOption(d,'$d')],
            onChanged:(x){store.update(newDecimals:x);setState((){});}),
          const SizedBox(height:19),
          ExpansionTile(tilePadding:EdgeInsets.zero,
            shape:const Border(),collapsedShape:const Border(),
            leading:const Icon(Icons.tune_outlined,size:21),
            title:const Text('Default financial inputs',style:TextStyle(fontWeight:FontWeight.w600)),
            childrenPadding:const EdgeInsets.only(bottom:12),
            children:[
              for(final k in labels.keys)...[
                TextField(controller:controls[k],
                  keyboardType:const TextInputType.numberWithOptions(decimal:true),
                  decoration:InputDecoration(labelText:labels[k]),
                  onChanged:(value){store.setPreference(k,value);}),
                const SizedBox(height:11),
              ],
              const Hint('Applies to new scenarios. Existing saved values are unchanged.'),
            ]),
          const SectionHead('Your data'),
          ListTile(contentPadding:EdgeInsets.zero,
            title:const Text('History'),
            trailing:Text('${store.history.length}')),
          Divider(height:1,color:Theme.of(context).dividerColor),
          ListTile(contentPadding:EdgeInsets.zero,
            title:const Text('Saved scenarios'),
            trailing:Text('${store.scenarios.length}')),
          Divider(height:1,color:Theme.of(context).dividerColor),
          ListTile(contentPadding:EdgeInsets.zero,
            leading:const Icon(Icons.copy_all_outlined,size:20),
            title:const Text('Copy local backup'),
            onTap:(){
              final payload=jsonEncode({'history':store.history,
                'scenarios':store.scenarios,'drafts':store.drafts,'preferences':store.preferences});
              Clipboard.setData(ClipboardData(text:payload));
              notice(context,'Local backup copied as JSON');
            }),
          ListTile(contentPadding:EdgeInsets.zero,
            leading:const Icon(Icons.settings_backup_restore_outlined,size:20),
            title:const Text('Restore local backup'),
            onTap:() async {
              final ctrl = TextEditingController();
              final payload = await showDialog<String>(context:context,
                builder:(ctx)=>AlertDialog(
                  title:const Text('Restore KALQO backup'),
                  content:SizedBox(width:double.maxFinite,child:TextField(
                    controller:ctrl,maxLines:7,minLines:3,
                    decoration:const InputDecoration(
                      hintText:'Paste the JSON backup saved from your old app'))),
                  actions:[
                    TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),
                    FilledButton(onPressed:()=>Navigator.pop(ctx,ctrl.text),
                      child:const Text('Restore')),
                  ]));
              ctrl.dispose();
              if(payload != null){
                final success = store.importBackup(payload);
                if(context.mounted) notice(context,
                  success ? 'Backup restored' : 'Invalid backup format');
              }
            }),
          ListTile(contentPadding:EdgeInsets.zero,
            leading:const Icon(Icons.delete_outline,size:20),
            title:const Text('Delete local data'),
            onTap:()async{
              final approved=await showDialog<bool>(context:context,
                builder:(ctx)=>AlertDialog(title:const Text('Delete all app data?'),
                  content:const Text('Saved scenarios, history and preferences will be deleted from this phone.'),
                  actions:[
                    TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
                    FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Delete'))]));
              if(approved==true){store.reset();if(context.mounted)Navigator.pop(context);}
            }),
          const SizedBox(height:22),
          const Hint('Private by design. Your data stays on this phone. Financial results are estimates.'),
        ],
      ));
  }

}
