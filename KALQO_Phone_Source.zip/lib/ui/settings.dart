import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/storage.dart';
import '../core/export.dart';
import 'common.dart';

class SettingsPage extends StatefulWidget {
  final AppStore store;
  const SettingsPage({super.key, required this.store});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final Map<String, TextEditingController> controls;
  static const labels = <String, String>{
    'bankRate':'Default annual bank interest (%)',
    'bankTax':'Default Turkish withholding (%)',
    'bankDays':'Default deposit term (days)',
    'vatRate':'Dutch VAT (%)',
    'basicPrice':'Basic subscription (€)',
    'mediumPrice':'Medium subscription (€)',
    'proPrice':'Pro subscription (€)',
  };
  static const defaults = <String, String>{
    'bankRate':'32','bankTax':'17.5','bankDays':'31','vatRate':'21',
    'basicPrice':'39','mediumPrice':'59','proPrice':'79',
  };
  @override
  void initState() {
    super.initState();
    controls = {for(final key in labels.keys) key: TextEditingController(text:widget.store.preferences[key] ?? defaults[key])};
  }
  @override
  void dispose() {
    for(final c in controls.values) { c.dispose(); }
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return Scaffold(appBar:AppBar(title:Text(tr(store,'Settings','Instellingen','Ayarlar'))),
      body:ListView(padding:const EdgeInsets.fromLTRB(20,12,20,42),children:[
        const SectionHead('Appearance & language'),
        KCard(child:Column(children:[
          DropdownButtonFormField<String>(initialValue:store.theme,
            decoration:const InputDecoration(labelText:'Theme'),
            items:const [DropdownMenuItem(value:'system',child:Text('System')),
              DropdownMenuItem(value:'light',child:Text('Light')),
              DropdownMenuItem(value:'dark',child:Text('Dark'))],
            onChanged:(x){if(x!=null){store.update(newTheme:x);setState((){});}}),
          const SizedBox(height:12),
          DropdownButtonFormField<String>(initialValue:store.language,
            decoration:const InputDecoration(labelText:'Language'),
            items:const [DropdownMenuItem(value:'nl',child:Text('Nederlands')),
              DropdownMenuItem(value:'en',child:Text('English')),
              DropdownMenuItem(value:'tr',child:Text('Türkçe'))],
            onChanged:(x){if(x!=null){store.update(newLanguage:x);setState((){});}}),
          const SizedBox(height:12),
          DropdownButtonFormField<int>(initialValue:store.decimals,
            decoration:const InputDecoration(labelText:'Decimal places'),
            items:[for(final d in [0,1,2,3,4]) DropdownMenuItem(value:d,child:Text('$d'))],
            onChanged:(x){if(x!=null){store.update(newDecimals:x);setState((){});}}),
        ])),
        const SectionHead('Default financial inputs'),
        KCard(child:Column(children:[
          for(final k in labels.keys) ...[
            TextField(controller:controls[k],keyboardType:const TextInputType.numberWithOptions(decimal:true),
              decoration:InputDecoration(labelText:labels[k]),
              onChanged:(value){store.setPreference(k,value);}),
            if(k!=labels.keys.last) const SizedBox(height:10),
          ],
          const Hint('New default values apply when a calculator has no saved draft. Changes to tax rates do not override previously saved scenarios.'),
        ])),
        const SectionHead('Your data'),
        KCard(child:Column(children:[
          ListTile(contentPadding:EdgeInsets.zero,title:const Text('Saved history'),
            trailing:Text('${store.history.length} entries')),
          ListTile(contentPadding:EdgeInsets.zero,title:const Text('Saved scenarios'),
            trailing:Text('${store.scenarios.length} entries')),
          FilledButton.tonalIcon(onPressed:(){
            final payload=jsonEncode({'history':store.history,'scenarios':store.scenarios,
              'drafts':store.drafts,'preferences':store.preferences});
            Clipboard.setData(ClipboardData(text:payload));
            notice(context,'Local backup copied as JSON');
          },icon:const Icon(Icons.copy_all_outlined),label:const Text('Copy local data backup')),
          const SizedBox(height:12),
          OutlinedButton.icon(onPressed:() async {
            final approved=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
              title:const Text('Delete all app data?'),content:const Text('All saved scenarios, calculator history and preferences will be deleted from this phone.'),
              actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
                FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Delete'))]));
            if(approved==true){store.reset();if(context.mounted){Navigator.pop(context);}}
          },icon:const Icon(Icons.delete_forever_outlined),label:const Text('Delete all local data')),
        ])),
        const SizedBox(height:10),
        const Hint('KALQO works offline, requires no account, and does not upload your financial data. Estimates are for planning, not tax filings.'),
      ]));
  }
}
