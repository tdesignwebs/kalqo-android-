import 'package:flutter/material.dart';
import 'core/storage.dart';
import 'ui/common.dart';
import 'ui/calculator.dart';
import 'ui/faiz.dart';
import 'ui/business.dart';
import 'ui/cars.dart';
import 'ui/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.init();
  runApp(KalqoApp(store:store));
}

class KalqoApp extends StatelessWidget {
  final AppStore store;
  const KalqoApp({super.key,required this.store});
  @override Widget build(BuildContext context) => AnimatedBuilder(
    animation:store,builder:(_,__)=> MaterialApp(
      title:'KALQO',debugShowCheckedModeBanner:false,
      theme:appTheme(Brightness.light),darkTheme:appTheme(Brightness.dark),
      themeMode:store.theme=='dark'?ThemeMode.dark:store.theme=='light'?ThemeMode.light:ThemeMode.system,
      home:KalqoHome(store:store)));
}

class KalqoHome extends StatefulWidget {
  final AppStore store;
  const KalqoHome({super.key,required this.store});
  @override State<KalqoHome> createState()=>_KalqoHomeState();
}
class _KalqoHomeState extends State<KalqoHome> {
  int index=0;
  @override Widget build(BuildContext context){
    final dark=Theme.of(context).brightness==Brightness.dark;
    const icons=[Icons.calculate_outlined,Icons.savings_outlined,Icons.stacked_line_chart_rounded,Icons.directions_car_outlined];
    const selectedIcons=[Icons.calculate_rounded,Icons.savings_rounded,Icons.stacked_line_chart_rounded,Icons.directions_car_rounded];
    const labels=['Calc','Faiz','AXREON','Cars'];
    return Scaffold(
      appBar:AppBar(toolbarHeight:75,titleSpacing:24,
        title:Row(mainAxisSize:MainAxisSize.min,children:[
          ClipRRect(borderRadius:BorderRadius.circular(10),
            child:Image.asset('assets/icon/kalqo_icon.png',width:37,height:37)),
          const SizedBox(width:11),
          const Text('KALQO',style:TextStyle(fontSize:17,letterSpacing:2.4,fontWeight:FontWeight.w800)),
        ]),
        actions:[
          IconButton(tooltip:dark?'Switch to light mode':'Switch to dark mode',
            onPressed:()=>widget.store.update(newTheme:dark?'light':'dark'),
            icon:Icon(dark?Icons.wb_sunny_outlined:Icons.nightlight_outlined,size:21)),
          IconButton(tooltip:'Settings',
            onPressed:()=>Navigator.of(context).push(MaterialPageRoute(
              builder:(_)=>SettingsPage(store:widget.store))),
            icon:const Icon(Icons.tune_rounded,size:21)),
          const SizedBox(width:12),
        ]),
      body:SafeArea(child:IndexedStack(index:index,children:[
        CalculatorPage(store:widget.store),
        FaizPage(store:widget.store),
        BusinessPage(store:widget.store),
        CarsPage(store:widget.store),
      ])),
      bottomNavigationBar:SafeArea(top:false,child:Container(
        decoration:BoxDecoration(color:Theme.of(context).scaffoldBackgroundColor,
          border:Border(top:BorderSide(color:Theme.of(context).dividerColor))),
        child:Padding(padding:const EdgeInsets.fromLTRB(12,9,12,3),
          child:Row(children:[for(var i=0;i<labels.length;i++)Expanded(
            child:Semantics(button:true,selected:index==i,label:labels[i],
              child:InkWell(borderRadius:BorderRadius.circular(15),
                onTap:()=>setState(()=>index=i),
                child:Padding(padding:const EdgeInsets.symmetric(vertical:5),
                  child:Column(mainAxisSize:MainAxisSize.min,children:[
                    SizedBox(height:33,child:Center(child:Icon(index==i?selectedIcons[i]:icons[i],
                      size:25,color:index==i?accent:muted(context)))),
                    const SizedBox(height:5),
                    Text(labels[i],maxLines:1,style:TextStyle(fontSize:11.5,letterSpacing:.05,
                      color:index==i?accent:muted(context),fontWeight:index==i?FontWeight.w700:FontWeight.w500)),
                    const SizedBox(height:5),
                    AnimatedContainer(duration:const Duration(milliseconds:180),height:3,width:index==i?17:0,
                      decoration:BoxDecoration(color:accent,borderRadius:BorderRadius.circular(8))),
                  ]))))),
          ])))),
    );
  }
}
