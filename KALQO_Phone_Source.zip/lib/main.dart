import 'package:flutter/material.dart';
import 'core/storage.dart';
import 'ui/common.dart';
import 'ui/calculator.dart';
import 'ui/faiz.dart';
import 'ui/business.dart';
import 'ui/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.init();
  runApp(KalqoApp(store: store));
}

class KalqoApp extends StatelessWidget {
  final AppStore store;
  const KalqoApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) =>
    MaterialApp(title: 'KALQO', debugShowCheckedModeBanner: false,
      theme: appTheme(Brightness.light), darkTheme: appTheme(Brightness.dark),
      themeMode: store.theme == 'dark' ? ThemeMode.dark : store.theme == 'light' ? ThemeMode.light : ThemeMode.system,
      home: KalqoHome(store: store)));
}

class KalqoHome extends StatefulWidget {
  final AppStore store;
  const KalqoHome({super.key, required this.store});
  @override
  State<KalqoHome> createState() => _KalqoHomeState();
}
class _KalqoHomeState extends State<KalqoHome> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final texts = [tr(store,'Calculator','Rekenmachine','Hesap Makinesi'),
      'Faiz', 'AXREON'];
    return Scaffold(
      appBar: AppBar(toolbarHeight: 74, titleSpacing: 20,
        title: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(11),
          child: Image.asset('assets/icon/kalqo_icon.png', width: 38, height: 38)),
          const SizedBox(width: 11), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('KALQO', style: TextStyle(fontSize: 18, letterSpacing: 1.5, fontWeight: FontWeight.w900)),
            Text('SMART CALCULATOR', style: TextStyle(fontSize: 9, letterSpacing: 1.1, color: accent,
              fontWeight: FontWeight.w800))])]),
        actions: [IconButton(tooltip: 'Settings', icon: const Icon(Icons.tune_rounded),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => SettingsPage(store: store)))), const SizedBox(width: 8)]),
      body: SafeArea(child: IndexedStack(index: index, children: [
        CalculatorPage(store: store), FaizPage(store: store), BusinessPage(store: store)])),
      bottomNavigationBar: NavigationBar(height: 72, selectedIndex: index,
        backgroundColor: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF1C2027) : Colors.white,
        indicatorColor: accent.withValues(alpha: .14),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (i) => setState(() => index = i), destinations: [
          NavigationDestination(icon: const Icon(Icons.calculate_outlined), selectedIcon: const Icon(Icons.calculate), label: texts[0]),
          NavigationDestination(icon: const Icon(Icons.savings_outlined), selectedIcon: const Icon(Icons.savings), label: texts[1]),
          NavigationDestination(icon: const Icon(Icons.bar_chart_rounded), selectedIcon: const Icon(Icons.stacked_bar_chart), label: texts[2]),
        ]));
  }
}
