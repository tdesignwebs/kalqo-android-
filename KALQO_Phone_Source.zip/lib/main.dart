import 'package:flutter/material.dart';
import 'core/storage.dart';
import 'ui/common.dart';
import 'ui/calculator.dart';
import 'ui/faiz.dart';
import 'ui/business.dart';
import 'ui/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.init();
  runApp(KalqoApp(store: store));
}

class KalqoApp extends StatelessWidget {
  final AppStore store;
  const KalqoApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) =>
    MaterialApp(title: 'KALQO', debugShowCheckedModeBanner: false,
      theme: appTheme(Brightness.light), darkTheme: appTheme(Brightness.dark),
      themeMode: store.theme == 'dark' ? ThemeMode.dark : store.theme == 'light' ? ThemeMode.light : ThemeMode.system,
      home: KalqoHome(store: store)));
}

class KalqoHome extends StatefulWidget {
  final AppStore store;
  const KalqoHome({super.key, required this.store});
  @override
  State<KalqoHome> createState() => _KalqoHomeState();
}
class _KalqoHomeState extends State<KalqoHome> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final texts = [tr(store,'Calculator','Rekenmachine','Hesap Makinesi'),
      'Faiz', 'AXREON'];
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(toolbarHeight: 67, titleSpacing: 23,
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(9),
            child: Image.asset('assets/icon/kalqo_icon.png',width:31,height:31)),
          const SizedBox(width: 10),
          const Text('KALQO',style:TextStyle(
            fontWeight:FontWeight.w800,letterSpacing:1.15,fontSize:17)),
        ]),
        actions: [
          IconButton(
            tooltip: dark ? 'Light mode' : 'Dark mode',
            icon: Icon(dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,size:22),
            onPressed: () => store.update(newTheme:dark?'light':'dark')),
          IconButton(tooltip: 'Settings', icon: const Icon(Icons.tune_rounded,size:22),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => SettingsPage(store: store)))),
          const SizedBox(width: 10),
        ]),
      body: SafeArea(child: IndexedStack(index:index,children:[
        CalculatorPage(store:store),FaizPage(store:store),BusinessPage(store:store)])),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border:Border(top:BorderSide(color:Theme.of(context).dividerColor.withValues(alpha:.7)))),
        child: NavigationBar(
          height: 68, selectedIndex:index,
          backgroundColor:dark?const Color(0xFF181D25):Colors.white,
          elevation: 0,
          indicatorColor:accent.withValues(alpha:dark?.18:.11),
          labelBehavior:NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected:(i)=>setState(()=>index=i),
          destinations:[
            NavigationDestination(icon:const Icon(Icons.calculate_outlined,size:23),
              selectedIcon:const Icon(Icons.calculate_rounded,size:23),label:texts[0]),
            const NavigationDestination(icon:Icon(Icons.savings_outlined,size:23),
              selectedIcon:Icon(Icons.savings_rounded,size:23),label:'Faiz'),
            const NavigationDestination(icon:Icon(Icons.bar_chart_outlined,size:23),
              selectedIcon:Icon(Icons.bar_chart_rounded,size:23),label:'AXREON'),
          ])),
    );
  }
}
