import 'package:flutter_test/flutter_test.dart';
import 'package:kalqo/core/calc.dart';
import 'package:kalqo/core/decimal.dart';
import 'package:kalqo/core/finance.dart';

void main() {
  test('decimal parsing and euro formatting', () {
    expect(Dec.parse('5.900,25').toFixed(2), '5900.25');
    expect(Dec.parse('2.717,81').toFixed(2), '2717.81');
    expect(Dec.parse('1234.5').localized(symbol: '€'), '€1.234,50');
  });
  test('calculator precedence, unary and percent', () {
    final calc = ExpressionCalculator();
    expect(calc.evaluate('2+3×4').toFixed(0), '14');
    expect(calc.evaluate('-(4+2)÷3').toFixed(0), '-2');
    expect(calc.evaluate('100×32%').toFixed(0), '32');
    expect(() => calc.evaluate('5÷0'), throwsStateError);
  });
  test('faiz 31-day example', () {
    final value = calculateInterest(InterestInput(principal: Dec.fromInt(100000),
      annualPercent: Dec.fromInt(32), taxPercent: Dec.parse('17.5'), periods: 1));
    expect(value.totalGross.toFixed(2), '2717.81');
    expect(value.totalTax.toFixed(2), '475.62');
    expect(value.totalNet.toFixed(2), '2242.19');
    expect(value.closingBalance.toFixed(2), '102242.19');
  });
  test('reinvest vs payout', () {
    InterestInput input(bool reinvest) => InterestInput(principal: Dec.fromInt(100000),
      annualPercent: Dec.fromInt(32), taxPercent: Dec.parse('17.5'), periods: 2, reinvest: reinvest);
    final a = calculateInterest(input(true));
    final b = calculateInterest(input(false));
    expect(a.totalNet > b.totalNet, true);
    expect(b.closingBalance.toFixed(2), '100000.00');
  });
  test('AXREON basic monthly revenue and fixed expense', () {
    final r = calculateBusiness(BusinessInput(clients: [0,100,0],
      prices: [Dec.fromInt(39), Dec.fromInt(59), Dec.fromInt(79)],
      expenses: [
        BusinessExpense(id: 'a', name: 'Supabase', amount: Dec.fromInt(20)),
        BusinessExpense(id: 'b', name: 'Domain', amount: Dec.fromInt(10), frequency: ExpenseFrequency.yearly),
      ], vatRate: Dec.fromInt(21), providerPercent: Dec.zero, providerFixed: Dec.zero));
    expect(r.monthlyRevenue.toFixed(2), '5900.00');
    expect(r.monthlyExpenses.toFixed(2), '20.83');
    expect(r.operatingProfit.toFixed(2), '5879.17');
    expect(r.outputVat.toFixed(2), '1239.00');
  });
  test('VAT included vs excluded', () {
    BusinessInput input(bool incl) => BusinessInput(clients: [1], prices: [Dec.fromInt(121)],
      expenses: [], vatRate: Dec.fromInt(21), providerPercent: Dec.zero,
      providerFixed: Dec.zero, pricesIncludeVat: incl);
    expect(calculateBusiness(input(true)).monthlyRevenue.toFixed(2), '100.00');
    expect(calculateBusiness(input(false)).monthlyRevenue.toFixed(2), '121.00');
  });
  test('progressive 2026 bracket and BV corporate rates', () {
    expect(progressiveBox1(Dec.fromInt(38883)).toFixed(2), '13900.67');
    expect(corporateTax(Dec.fromInt(300000)).toFixed(0), '63800');
  });
  test('growth and zero clients', () {
    final rows = simulateGrowth(startClients: 0, newClients: 10,
      churnPercent: Dec.zero, price: Dec.fromInt(59),
      startingExpenses: Dec.fromInt(20), expenseGrowthPercent: Dec.zero,
      effectiveTaxPercent: Dec.fromInt(30));
    expect(rows.length, 12);
    expect(rows.first.revenue.toFixed(0), '590');
    expect(rows.last.clients, 120);
  });
}
