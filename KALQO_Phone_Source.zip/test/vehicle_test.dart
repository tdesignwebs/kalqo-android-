import 'package:flutter_test/flutter_test.dart';
import 'package:kalqo/core/vehicle.dart';
import 'package:kalqo/ui/cars.dart';

void main(){
  test('Dutch plates normalize correctly',(){
    expect(normalizeDutchPlate('ab-123-c'),'AB123C');
    expect(normalizeDutchPlate(' 1-ABC-23 '),'1ABC23');
  });
  test('RDW dates use day-month-year formatting',(){
    expect(formatRdwDate('20251017'),'17-10-2025');
    expect(formatRdwDate(''),'—');
  });
  test('RDW odometer assessment is not treated as an exact mileage',(){
    final record=VehicleRecord.fromRdw({
      'merk':'VOLVO','handelsbenaming':'XC60',
      'datum_eerste_toelating':'20210214',
      'tellerstandoordeel':'Logisch',
      'jaar_laatste_registratie_tellerstand':'2025',
    },'AB123C');
    expect(record.make,'VOLVO');
    expect(record.year,'2021');
    expect(record.odometerJudgement,'Logisch');
    expect(record.odometerYear,'2025');
  });
  test('US VIN decoding contains only provided specifications',(){
    final result=VehicleRecord.fromNhtsa({'Make':'TOYOTA','Model':'CAMRY','ModelYear':'2022'},
      '4T1BE46K57U092147');
    expect(result.make,'TOYOTA');
    expect(result.year,'2022');
    expect(result.odometerJudgement,'');
  });
  test('Inspection hit targets are stable',(){
    expect(VehicleDiagram.partForPoint(.5,.06),'Front bumper');
    expect(VehicleDiagram.partForPoint(.5,.22),'Bonnet');
    expect(VehicleDiagram.partForPoint(.5,.48),'Roof');
    expect(VehicleDiagram.partForPoint(.19,.40),'Left front door');
    expect(VehicleDiagram.partForPoint(.5,.95),'Rear bumper');
    expect(VehicleDiagram.partForPoint(.02,.1),isNull);
  });
}
